package com.example.friendutil;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/**
 * VoidDls click-GUI: one centered window with four tabs on top (PvE, PvP, Cheat, Visuals), a search box,
 * modules laid out in a grid with toggle switches. LMB toggles a module, RMB opens its settings on the right.
 */
public class MenuScreen extends Screen {

    private static final String[] TABS = {"PvE", "PvP", "Cheat", "Visuals"};
    // "@ores" and "@world" are settings-only entries (no switch)
    private static final String[][] TAB_MODULES = {
            {"mobaura", "autoeat", "autotool", "autofish", "automine", "autoplant", "autoharvest", "autofarm",
                    "autostash", "autobreed", "autowarden", "autorespawn", "autowalk", "antiafk", "@ores"},
            {"killaura", "ka_crits", "triggerbot", "aimassist", "autototem", "autogapple"},
            {"fly", "speed", "step", "spider", "jesus", "autosprint"},
            {"esp_players", "esp_mobs", "esp_items", "gearview", "ore_esp", "trajectory", "targethud", "dmgnum",
                    "hitfx", "cooldowns", "fullbright", "coords", "targetesp", "trails", "jumpcircles",
                    "blockoverlay", "worldpart", "fog", "@ores", "@world"}
    };
    private static final String[][] ORES = {
            {"Coal", "coal_ore"}, {"Iron", "iron_ore"}, {"Copper", "copper_ore"}, {"Gold", "gold_ore"},
            {"Redstone", "redstone_ore"}, {"Lapis", "lapis_ore"}, {"Diamond", "diamond_ore"},
            {"Emerald", "emerald_ore"}, {"Quartz", "quartz_ore"}, {"Debris", "ancient_debris"}
    };

    private static final int RH = 11;                             // settings row height
    private static final int POPW = 128;                          // settings popup width
    private static final int TOPH = 26, CH = 18, BOTH = 14, HDR = 15;

    private static int tab = 0;
    private static final int[] SCROLL = new int[4];
    private static String popup = null;                           // module id (or "@ores" / "@world") whose settings are open

    // swatch: small color square on the row (header of a color setting); pick: a palette grid row
    private record Row(String text, int color, boolean on, Runnable click, Runnable rclick,
                       IntSupplier swatch, IntConsumer pick) {
        Row(String text, int color, boolean on, Runnable click, Runnable rclick) {
            this(text, color, on, click, rclick, null, null);
        }
    }

    private static final int SW = 9;                              // palette cell size
    private static final Set<String> PAL_OPEN = new HashSet<>();

    private int palCols() {
        return Math.max(1, (POPW - 6) / SW);
    }

    private int rowH(Row r) {
        if (r.pick() == null) return RH;
        int n = FriendUtilClient.COLOR_NAMES.length;
        return ((n + palCols() - 1) / palCols()) * SW + 3;
    }

    // "Color: Name" header (click = open the palette, RMB = next color) + the palette grid under it
    private static List<Row> colorRows(String key, IntSupplier get, IntConsumer set) {
        List<Row> o = new ArrayList<>();
        int n = FriendUtilClient.COLOR_NAMES.length;
        o.add(new Row("  Color: " + FriendUtilClient.COLOR_NAMES[get.getAsInt()], 0xFFFFFF55, false,
                () -> { if (!PAL_OPEN.remove(key)) PAL_OPEN.add(key); },
                () -> set.accept((get.getAsInt() + 1) % n), get, null));
        if (PAL_OPEN.contains(key)) o.add(new Row("", 0, false, null, null, get, set));
        return o;
    }



    private EditBox search, customBox;
    private int winX, winY, winW, winH, gridX, gridY, gridW, gridH, cols, cellW;
    private int tabX0, tabW;
    private int popX, popY, popH;

    public MenuScreen() {
        super(Component.literal("VoidDls"));
    }

    private static Module find(String id) {
        for (Module m : FriendUtilClient.modules()) {
            if (m.id.equals(id)) return m;
        }
        return null;
    }

    private static String labelOf(String id) {
        if ("@ores".equals(id)) return "Ores";
        if ("@world".equals(id)) return "World";
        Module m = find(id);
        return m == null ? null : m.name;
    }

    private static Row cycleRow(String label, String[] names, IntSupplier get, IntConsumer set) {
        int n = names.length;
        return new Row("  " + label + ": " + names[get.getAsInt()], 0xFFFFFF55, false,
                () -> set.accept((get.getAsInt() + 1) % n),
                () -> set.accept((get.getAsInt() + n - 1) % n));
    }

    private static boolean hasSettings(String id) {
        switch (id) {
            case "@ores": case "@world":
            case "autowarden": case "hitfx": case "targetesp": case "trails":
            case "jumpcircles": case "blockoverlay": case "worldpart": case "fog":
                return true;
            default:
                return false;
        }
    }

    private static List<Row> settingsRows(String id) {
        List<Row> o = new ArrayList<>();
        switch (id) {
            case "autowarden":
                o.add(new Row("  Open at " + FriendUtilClient.wardenOpenAt + "s", 0xFFFFFF55, false, () ->
                        FriendUtilClient.wardenOpenAt = FriendUtilClient.wardenOpenAt >= 5 ? 0 : FriendUtilClient.wardenOpenAt + 1,
                        null));
                o.add(new Row("  Route: " + FriendUtilClient.wardenQueueSize() + " an", 0xFF888888, false, null, null));
                break;
            case "hitfx":
                o.addAll(colorRows("hit", () -> FriendUtilClient.hitColor, v -> FriendUtilClient.hitColor = v));
                o.add(cycleRow("Count", FriendUtilClient.COUNT_NAMES, () -> FriendUtilClient.hitCount, v -> FriendUtilClient.hitCount = v));
                o.add(new Row("  World: " + (FriendUtilClient.hitWorldFx ? "On" : "Off"), 0xFFFFFF55, false,
                        () -> FriendUtilClient.hitWorldFx = !FriendUtilClient.hitWorldFx, null));
                o.add(cycleRow("Particle", FriendUtilClient.PFX_NAMES, () -> FriendUtilClient.hitType, v -> FriendUtilClient.hitType = v));
                break;
            case "targetesp":
                o.addAll(colorRows("te", () -> FriendUtilClient.teColor, v -> FriendUtilClient.teColor = v));
                o.add(cycleRow("Style", FriendUtilClient.TE_STYLE_NAMES, () -> FriendUtilClient.teStyle, v -> FriendUtilClient.teStyle = v));
                o.add(cycleRow("Size", FriendUtilClient.SIZE_NAMES, () -> FriendUtilClient.teSize, v -> FriendUtilClient.teSize = v));
                o.add(cycleRow("Speed", FriendUtilClient.SPEED_NAMES, () -> FriendUtilClient.teSpeed, v -> FriendUtilClient.teSpeed = v));
                o.add(cycleRow("Line", FriendUtilClient.LINE_NAMES, () -> FriendUtilClient.teLine, v -> FriendUtilClient.teLine = v));
                break;
            case "trails":
                o.addAll(colorRows("tr", () -> FriendUtilClient.trColor, v -> FriendUtilClient.trColor = v));
                o.add(cycleRow("Length", FriendUtilClient.TR_LEN_NAMES, () -> FriendUtilClient.trLength, v -> FriendUtilClient.trLength = v));
                o.add(cycleRow("Line", FriendUtilClient.LINE_NAMES, () -> FriendUtilClient.trLine, v -> FriendUtilClient.trLine = v));
                o.add(cycleRow("Who", FriendUtilClient.TR_WHO_NAMES, () -> FriendUtilClient.trWho, v -> FriendUtilClient.trWho = v));
                break;
            case "jumpcircles":
                o.addAll(colorRows("jc", () -> FriendUtilClient.jcColor, v -> FriendUtilClient.jcColor = v));
                o.add(cycleRow("Radius", FriendUtilClient.SIZE_NAMES, () -> FriendUtilClient.jcRadius, v -> FriendUtilClient.jcRadius = v));
                o.add(cycleRow("Speed", FriendUtilClient.SPEED_NAMES, () -> FriendUtilClient.jcSpeed, v -> FriendUtilClient.jcSpeed = v));
                o.add(cycleRow("Line", FriendUtilClient.LINE_NAMES, () -> FriendUtilClient.jcLine, v -> FriendUtilClient.jcLine = v));
                break;
            case "blockoverlay":
                o.addAll(colorRows("bo", () -> FriendUtilClient.boColor, v -> FriendUtilClient.boColor = v));
                o.add(cycleRow("Mode", FriendUtilClient.BO_MODE_NAMES, () -> FriendUtilClient.boMode, v -> FriendUtilClient.boMode = v));
                o.add(cycleRow("Line", FriendUtilClient.LINE_NAMES, () -> FriendUtilClient.boLine, v -> FriendUtilClient.boLine = v));
                o.add(cycleRow("Pulse", FriendUtilClient.OFFON_NAMES, () -> FriendUtilClient.boPulse, v -> FriendUtilClient.boPulse = v));
                break;
            case "fog":
                o.addAll(colorRows("fog", () -> FriendUtilClient.fogColorIdx, v -> FriendUtilClient.fogColorIdx = v));
                o.add(cycleRow("Distance", FriendUtilClient.FOG_DIST_NAMES, () -> FriendUtilClient.fogDistIdx, v -> FriendUtilClient.fogDistIdx = v));
                o.add(cycleRow("Start", FriendUtilClient.FOG_START_NAMES, () -> FriendUtilClient.fogStartIdx, v -> FriendUtilClient.fogStartIdx = v));
                o.add(cycleRow("Sky", FriendUtilClient.SKY_NAMES, () -> FriendUtilClient.skyMode, v -> FriendUtilClient.skyMode = v));
                break;
            case "worldpart":
                o.add(cycleRow("Type", FriendUtilClient.PFX_NAMES, () -> FriendUtilClient.wpType, v -> FriendUtilClient.wpType = v));
                o.add(cycleRow("Density", FriendUtilClient.DENSITY_NAMES, () -> FriendUtilClient.wpDensity, v -> FriendUtilClient.wpDensity = v));
                o.add(cycleRow("Range", FriendUtilClient.RANGE_NAMES, () -> FriendUtilClient.wpRange, v -> FriendUtilClient.wpRange = v));
                break;
            default:
                break;
        }
        return o;
    }

    private static List<Row> worldRows(int accent) {
        List<Row> out = new ArrayList<>();
        int wn = FriendUtilClient.WEATHER_NAMES.length, tn = FriendUtilClient.TINT_NAMES.length;
        out.add(new Row("Weather: " + FriendUtilClient.WEATHER_NAMES[FriendUtilClient.weatherMode], accent,
                FriendUtilClient.weatherMode != 0,
                () -> FriendUtilClient.weatherMode = (FriendUtilClient.weatherMode + 1) % wn,
                () -> FriendUtilClient.weatherMode = (FriendUtilClient.weatherMode + wn - 1) % wn));
        out.add(new Row("Tint: " + FriendUtilClient.TINT_NAMES[FriendUtilClient.tintMode], accent,
                FriendUtilClient.tintMode != 0,
                () -> FriendUtilClient.tintMode = (FriendUtilClient.tintMode + 1) % tn,
                () -> FriendUtilClient.tintMode = (FriendUtilClient.tintMode + tn - 1) % tn));
        if (FriendUtilClient.tintMode != 0) {
            out.add(new Row("  Strength " + FriendUtilClient.TINT_STRENGTH[FriendUtilClient.tintStrength] + "%", 0xFFFFFF55, false,
                    () -> FriendUtilClient.tintStrength = (FriendUtilClient.tintStrength + 1) % FriendUtilClient.TINT_STRENGTH.length,
                    null));
        }
        out.add(cycleRow("Distance", FriendUtilClient.RD_NAMES, () -> FriendUtilClient.rdIndex, v -> FriendUtilClient.rdIndex = v));
        Module pm = find("particles");
        if (pm != null) {
            out.add(new Row(pm.name, accent, pm.enabled, () -> pm.enabled = !pm.enabled, null));
        }
        out.add(new Row("  Type: " + FriendUtilClient.PFX_NAMES[FriendUtilClient.particleType], 0xFFFFFF55, false,
                () -> FriendUtilClient.particleType = (FriendUtilClient.particleType + 1) % FriendUtilClient.PFX_NAMES.length,
                null));
        out.add(new Row("  Mode: " + FriendUtilClient.PMODE_NAMES[FriendUtilClient.particleMode], 0xFFFFFF55, false,
                () -> FriendUtilClient.particleMode = (FriendUtilClient.particleMode + 1) % FriendUtilClient.PMODE_NAMES.length,
                null));
        out.add(new Row("  Hit fx: " + (FriendUtilClient.hitWorldFx ? "On" : "Off"), 0xFFFFFF55, false,
                () -> FriendUtilClient.hitWorldFx = !FriendUtilClient.hitWorldFx,
                null));
        return out;
    }

    private static List<Row> oreRows(int accent) {
        List<Row> out = new ArrayList<>();
        for (String[] o : ORES) {
            String key = o[1];
            out.add(new Row(o[0], accent, FriendUtilClient.mineSet.contains(key), () -> {
                if (!FriendUtilClient.mineSet.remove(key)) FriendUtilClient.mineSet.add(key);
            }, null));
        }
        return out;
    }

    private static List<Row> popupRows(int accent) {
        if ("@ores".equals(popup)) return oreRows(accent);
        if ("@world".equals(popup)) return worldRows(accent);
        return popup == null ? new ArrayList<>() : settingsRows(popup);
    }

    private List<String> ids() {
        List<String> out = new ArrayList<>();
        String q = search == null ? "" : search.getValue().trim().toLowerCase();
        if (q.isEmpty()) {
            for (String id : TAB_MODULES[tab]) if (labelOf(id) != null) out.add(id);
            return out;
        }
        Set<String> seen = new LinkedHashSet<>();
        for (String[] t : TAB_MODULES) {
            for (String id : t) {
                String l = labelOf(id);
                if (l != null && l.toLowerCase().contains(q) && seen.add(id)) out.add(id);
            }
        }
        return out;
    }

    private void layout() {
        winW = Math.min(this.width - 12, 400);
        winH = Math.min(this.height - 12, 260);
        winX = (this.width - winW) / 2;
        winY = (this.height - winH) / 2;
        gridX = winX + 8;
        gridY = winY + TOPH + 6;
        int right = winX + winW - 8 - (popup != null ? POPW + 6 : 0);
        gridW = right - gridX;
        gridH = winY + winH - BOTH - gridY - 2;
        cols = Mth.clamp(gridW / 104, 1, 3);
        cellW = gridW / cols;
        int logoW = this.font.width("VoidDls");
        tabX0 = winX + 8 + logoW + 14;
        tabW = Mth.clamp((winW - 16 - logoW - 14 - 100) / 4, 30, 46);
    }

    private static void panel(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x + 1, y, x + w - 1, y + h, color);
        g.fill(x, y + 1, x + 1, y + h - 1, color);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
    }

    private static void toggle(GuiGraphics g, int x, int y, boolean on, int accent) {
        int col = on ? accent : 0xFF30303C;
        g.fill(x + 1, y, x + 17, y + 9, col);
        g.fill(x, y + 1, x + 18, y + 8, col);
        int kx = on ? x + 10 : x + 1;
        g.fill(kx, y + 1, kx + 7, y + 8, on ? 0xFFFFFFFF : 0xFF8C8CA0);
    }

    private static boolean inBox(EditBox b, double mx, double my) {
        return b != null && b.visible && mx >= b.getX() && mx < b.getX() + b.getWidth()
                && my >= b.getY() && my < b.getY() + b.getHeight();
    }

    @Override
    protected void init() {
        search = new EditBox(this.font, 0, 0, 84, 14, Component.literal("search"));
        search.setHint(Component.literal("Search..."));
        search.setMaxLength(24);
        this.addWidget(search);

        // custom block id (AutoMine / Ore ESP), shown inside the Ores settings
        customBox = new EditBox(this.font, 0, 0, POPW - 8, 14, Component.literal("block id"));
        customBox.setMaxLength(64);
        customBox.setValue(FriendUtilClient.customQuery);
        customBox.setResponder(s -> FriendUtilClient.customQuery = s.trim().toLowerCase());
        customBox.visible = false;
        this.addWidget(customBox);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float a) {
        super.render(g, mx, my, a);
        long now = System.currentTimeMillis();
        layout();
        int accent = FriendUtilClient.hudColor(now, 0);
        int tint = (accent & 0x00FFFFFF) | 0x38000000;

        // window + top bar
        panel(g, winX, winY, winW, winH, 0xFF262632);
        panel(g, winX + 1, winY + 1, winW - 2, winH - 2, 0xF20E0E13);
        g.fill(winX + 1, winY + TOPH, winX + winW - 1, winY + TOPH + 1, 0xFF22222C);
        g.fill(winX + 8, winY + 8, winX + 11, winY + 18, accent);
        g.drawString(this.font, "Void", winX + 15, winY + 9, 0xFFFFFFFF, true);
        g.drawString(this.font, "Dls", winX + 15 + this.font.width("Void"), winY + 9, accent, true);

        // tabs
        boolean searching = !search.getValue().isBlank();
        for (int i = 0; i < TABS.length; i++) {
            int tx = tabX0 + i * tabW;
            boolean sel = i == tab && !searching;
            boolean hov = mx >= tx && mx < tx + tabW && my >= winY + 3 && my < winY + TOPH;
            if (sel) {
                g.fill(tx, winY + 5, tx + tabW - 2, winY + TOPH - 3, tint);
                g.fill(tx, winY + TOPH - 2, tx + tabW - 2, winY + TOPH, accent);
            }
            g.drawString(this.font, TABS[i], tx + (tabW - 2 - this.font.width(TABS[i])) / 2, winY + 9,
                    sel ? 0xFFFFFFFF : (hov ? 0xFFCCCCDD : 0xFF8A8A9A), true);
        }

        // search box (top right)
        int sw = Mth.clamp(winW / 4, 64, 96);
        search.setX(winX + winW - 8 - sw);
        search.setY(winY + 6);
        search.setWidth(sw);
        search.render(g, mx, my, a);

        // module grid
        List<String> ids = ids();
        int rowsN = (ids.size() + cols - 1) / cols;
        int visRows = Math.max(1, gridH / CH);
        int maxScroll = Math.max(0, rowsN - visRows);
        SCROLL[tab] = Mth.clamp(SCROLL[tab], 0, maxScroll);
        int first = SCROLL[tab];
        for (int i = 0; i < ids.size(); i++) {
            int r = i / cols - first, c = i % cols;
            if (r < 0 || r >= visRows) continue;
            int cx = gridX + c * cellW, cy = gridY + r * CH;
            String id = ids.get(i);
            boolean special = id.startsWith("@");
            Module m = special ? null : find(id);
            boolean on = m != null && m.enabled;
            boolean hover = mx >= cx && mx < cx + cellW - 3 && my >= cy && my < cy + CH - 2;
            g.fill(cx, cy, cx + cellW - 3, cy + CH - 2, hover ? 0xFF1E1E29 : 0xFF15151C);
            if (on) g.fill(cx, cy, cx + cellW - 3, cy + CH - 2, 0x18000000 | (accent & 0x00FFFFFF));
            if (id.equals(popup)) g.fill(cx, cy, cx + 2, cy + CH - 2, accent);
            g.drawString(this.font, labelOf(id), cx + 6, cy + 4, on ? 0xFFFFFFFF : 0xFF9A9AAA, true);
            if (special) {
                g.drawString(this.font, ">", cx + cellW - 14, cy + 4, 0xFF777788, true);
            } else {
                if (hasSettings(id)) g.drawString(this.font, ">", cx + cellW - 36, cy + 4, 0xFF555566, true);
                toggle(g, cx + cellW - 29, cy + 3, on, accent);
            }
        }
        if (maxScroll > 0) {                                      // scroll bar
            int thumbH = Math.max(8, gridH * visRows / rowsN);
            int thumbY = gridY + (gridH - thumbH) * first / maxScroll;
            g.fill(gridX + gridW, gridY, gridX + gridW + 2, gridY + gridH, 0xFF1A1A22);
            g.fill(gridX + gridW, thumbY, gridX + gridW + 2, thumbY + thumbH, accent);
        }
        if (ids.isEmpty()) {
            g.drawString(this.font, "Nothing found", gridX + 6, gridY + 4, 0xFF777788, true);
        }

        // footer
        String hint = "LMB toggle  |  RMB settings  |  wheel scroll";
        g.drawString(this.font, hint, winX + (winW - this.font.width(hint)) / 2, winY + winH - BOTH + 3, 0xFF666677, true);

        // settings popup
        customBox.visible = false;
        if (popup != null) {
            List<Row> rows = popupRows(accent);
            boolean ores = "@ores".equals(popup);
            int ph = HDR + 3 + (ores ? 30 : 0);
            for (Row r0 : rows) ph += rowH(r0);
            popX = winX + winW - 8 - POPW;
            popY = Math.max(2, Math.min(winY + TOPH + 4, this.height - 2 - ph));
            popH = ph;
            panel(g, popX, popY, POPW, ph, 0xFF262632);
            panel(g, popX + 1, popY + 1, POPW - 2, ph - 2, 0xF2101016);
            g.fill(popX + 1, popY + HDR - 1, popX + POPW - 1, popY + HDR, accent);
            g.drawString(this.font, labelOf(popup), popX + 5, popY + 4, 0xFFFFFFFF, true);
            g.drawString(this.font, "x", popX + POPW - 10, popY + 4, 0xFF999AAA, true);

            int ry = popY + HDR;
            for (Row r : rows) {
                int rh = rowH(r);
                if (r.pick() != null) {
                    int pc = palCols(), n = FriendUtilClient.COLOR_NAMES.length, sel = r.swatch().getAsInt();
                    for (int i = 0; i < n; i++) {
                        int sx = popX + 4 + (i % pc) * SW, sy = ry + 1 + (i / pc) * SW;
                        g.fill(sx, sy, sx + SW - 1, sy + SW - 1, 0xFF000000 | FriendUtilClient.fxRgb(i, now, i * 8));
                        if (i == sel) {
                            g.fill(sx - 1, sy - 1, sx + SW, sy, 0xFFFFFFFF);
                            g.fill(sx - 1, sy + SW - 1, sx + SW, sy + SW, 0xFFFFFFFF);
                            g.fill(sx - 1, sy, sx, sy + SW - 1, 0xFFFFFFFF);
                            g.fill(sx + SW - 1, sy, sx + SW, sy + SW - 1, 0xFFFFFFFF);
                        }
                    }
                    ry += rh;
                    continue;
                }
                boolean hover = mx >= popX && mx < popX + POPW && my >= ry && my < ry + RH;
                if (r.on()) {
                    g.fill(popX + 1, ry, popX + POPW - 1, ry + RH, (r.color() & 0x00FFFFFF) | 0x30000000);
                    g.fill(popX + 1, ry, popX + 2, ry + RH, r.color());
                }
                if (hover) g.fill(popX + 1, ry, popX + POPW - 1, ry + RH, 0x20FFFFFF);
                g.drawString(this.font, r.text().strip(), popX + 6, ry + 1,
                        r.on() ? r.color() : (r.click() != null && r.color() == 0xFFFFFF55 ? 0xFFFFFF55 : 0xFFAAAAAA), true);
                if (r.swatch() != null) {
                    g.fill(popX + POPW - 18, ry + 2, popX + POPW - 10, ry + RH - 2,
                            0xFF000000 | FriendUtilClient.fxRgb(r.swatch().getAsInt(), now, 0));
                }
                if (r.rclick() != null) g.drawString(this.font, ">", popX + POPW - 8, ry + 1, 0xFF666666, true);
                ry += rh;
            }
            if (ores) {
                g.drawString(this.font, "Custom block id", popX + 5, popY + ph - 28, 0xFF888888, true);
                customBox.setX(popX + 4);
                customBox.setY(popY + ph - 17);
                customBox.visible = true;
                customBox.render(g, mx, my, a);
            }
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        int btn = event.button();
        layout();
        if (inBox(search, mx, my) || inBox(customBox, mx, my)) return super.mouseClicked(event, doubleClick);

        // settings popup
        if (popup != null && mx >= popX && mx < popX + POPW && my >= popY && my < popY + popH) {
            if (my < popY + HDR) {
                if (btn == 0 && mx >= popX + POPW - 14) popup = null;
                return true;
            }
            int ry = popY + HDR;
            for (Row r : popupRows(0xFFFFFFFF)) {
                int rh = rowH(r);
                if (my >= ry && my < ry + rh) {
                    if (r.pick() != null) {
                        int pc = palCols();
                        int col = ((int) mx - popX - 4) / SW, row = ((int) my - ry - 1) / SW;
                        int idx = row * pc + col;
                        if (btn == 0 && col >= 0 && col < pc && row >= 0 && idx < FriendUtilClient.COLOR_NAMES.length) {
                            r.pick().accept(idx);
                        }
                    } else if (btn == 0 && r.click() != null) {
                        r.click().run();
                    } else if (btn == 1 && r.rclick() != null) {
                        r.rclick().run();
                    }
                    return true;
                }
                ry += rh;
            }
            return true;
        }

        // tabs
        if (btn == 0 && my >= winY + 3 && my < winY + TOPH) {
            for (int i = 0; i < TABS.length; i++) {
                int tx = tabX0 + i * tabW;
                if (mx >= tx && mx < tx + tabW) {
                    tab = i;
                    popup = null;
                    search.setValue("");
                    return true;
                }
            }
        }

        // module grid
        if (mx >= gridX && mx < gridX + gridW && my >= gridY && my < gridY + gridH) {
            List<String> ids = ids();
            int c = ((int) mx - gridX) / cellW, r = ((int) my - gridY) / CH;
            int idx = (r + SCROLL[tab]) * cols + c;
            if (c < cols && idx >= 0 && idx < ids.size()) {
                String id = ids.get(idx);
                boolean special = id.startsWith("@");
                if (special || (btn == 1 && hasSettings(id))) {
                    popup = id.equals(popup) ? null : id;
                } else if (btn == 0) {
                    Module m = find(id);
                    if (m != null) m.enabled = !m.enabled;
                }
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (mx >= gridX && mx < gridX + gridW && my >= gridY && my < gridY + gridH && scrollY != 0) {
            SCROLL[tab] = Math.max(0, SCROLL[tab] - (int) Math.signum(scrollY));
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }
}
