package com.example.friendutil.mixin;

import com.example.friendutil.FriendUtilClient;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.renderer.fog.FogData;
import net.minecraft.client.renderer.fog.FogRenderer;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FogRenderer.class)
public abstract class FogRendererMixin {

    // 1.21.11: setupFog builds a FogData locally and returns the fog color. require = 0 so a
    // mismatch only disables the fog/sky feature instead of crashing the game.
    @Inject(method = "setupFog", at = @At("RETURN"), require = 0)
    private void friendutil$fog(CallbackInfoReturnable<Vector4f> cir, @Local FogData fogData) {
        FriendUtilClient.applyFog(fogData);
    }
}
