package com.example.friendutil;

import net.minecraft.client.KeyMapping;

public final class Module {
    public final String id;
    public final String name;
    public boolean enabled = false;
    public KeyMapping key;

    public Module(String id, String name) {
        this.id = id;
        this.name = name;
    }
}
