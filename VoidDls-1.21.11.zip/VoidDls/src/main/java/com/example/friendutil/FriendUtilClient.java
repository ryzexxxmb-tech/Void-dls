package com.example.friendutil;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class FriendUtilClient implements ClientModInitializer {

    public static final String MOD_ID = "friendutil";

    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));

    // ---- toggle modules (each gets its own rebindable key) ----
    public static final Module FULLBRIGHT  = new Module("fullbright",  "Fullbright");
    public static final Module AUTOTOTEM   = new Module("autototem",   "AutoTotem");
    public static final Module FLY         = new Module("fly",         "Fly");
    public static final Module ESP_PLAYERS = new Module("esp_players", "ESP Players");
    public static final Module ESP_MOBS    = new Module("esp_mobs",    "ESP Mobs");
    public static final Module ESP_ITEMS   = new Module("esp_items",   "ESP Items");
    public static final Module AUTOSPRINT  = new Module("autosprint",  "AutoSprint");
    public static final Module AUTOWALK    = new Module("autowalk",    "AutoWalk");
    public static final Module COORDS      = new Module("coords",      "Coords");
    public static final Module AUTORESPAWN = new Module("autorespawn", "AutoRespawn");
    public static final Module ANTIAFK     = new Module("antiafk",     "AntiAFK");
    public static final Module KILLAURA    = new Module("killaura",    "KillAura");
    public static final Module GEARVIEW    = new Module("gearview",    "GearView");
    public static final Module KA_CRITS    = new Module("ka_crits",    "KA Crits");
    public static final Module AUTOMINE    = new Module("automine",    "AutoMine");
    public static final Module ORE_ESP     = new Module("ore_esp",     "Ore ESP");
    public static final Module TRIGGERBOT  = new Module("triggerbot",  "TriggerBot");
    public static final Module AIMASSIST   = new Module("aimassist",   "AimAssist");
    public static final Module SPEED       = new Module("speed",       "Speed");
    public static final Module STEP        = new Module("step",        "Step");
    public static final Module SPIDER      = new Module("spider",      "Spider");
    public static final Module JESUS       = new Module("jesus",       "Jesus");
    public static final Module AUTOGAPPLE  = new Module("autogapple",  "AutoGapple");
    public static final Module AUTOWARDEN  = new Module("autowarden",  "AutoWarden");
    public static final Module MOBAURA     = new Module("mobaura",     "MobAura");
    public static final Module AUTOEAT     = new Module("autoeat",     "AutoEat");
    public static final Module AUTOTOOL    = new Module("autotool",    "AutoTool");
    public static final Module AUTOFISH    = new Module("autofish",    "AutoFish");
    public static final Module TRAJECTORY  = new Module("trajectory",  "Trajectory");
    public static final Module TARGETHUD   = new Module("targethud",   "TargetHUD");
    public static final Module DMGNUM      = new Module("dmgnum",      "DmgNumbers");
    public static final Module HITFX       = new Module("hitfx",       "HitFX");
    public static final Module COOLDOWNS   = new Module("cooldowns",   "Cooldowns");
    public static final Module PARTICLES   = new Module("particles",   "Particles");
    public static final Module TARGETESP   = new Module("targetesp",   "TargetESP");
    public static final Module TRAILS      = new Module("trails",      "Trails");
    public static final Module JUMPCIRCLES = new Module("jumpcircles", "JumpCircles");
    public static final Module BLOCKOVERLAY= new Module("blockoverlay","BlockOverlay");
    public static final Module WORLDPART   = new Module("worldpart",   "WorldParticles");
    public static final Module FOG         = new Module("fog",         "Fog");
    public static final Module AUTOPLANT   = new Module("autoplant",   "AutoPlant");
    public static final Module AUTOHARVEST = new Module("autoharvest", "AutoHarvest");
    public static final Module AUTOFARM    = new Module("autofarm",    "AutoFarm");
    public static final Module AUTOSTASH   = new Module("autostash",   "AutoStash");
    public static final Module AUTOBREED   = new Module("autobreed",   "AutoBreed");

    private static final Module[] MODULES = {
            FULLBRIGHT, AUTOTOTEM, FLY, ESP_PLAYERS, ESP_MOBS, ESP_ITEMS,
            AUTOSPRINT, AUTOWALK, COORDS, AUTORESPAWN, ANTIAFK, KILLAURA, GEARVIEW, KA_CRITS, AUTOMINE, ORE_ESP,
            TRIGGERBOT, AIMASSIST, SPEED, STEP, SPIDER, JESUS, AUTOGAPPLE, AUTOWARDEN,
            MOBAURA, AUTOEAT, AUTOTOOL, AUTOFISH, TRAJECTORY,
            TARGETHUD, DMGNUM, HITFX, COOLDOWNS, PARTICLES,
            TARGETESP, TRAILS, JUMPCIRCLES, BLOCKOVERLAY, WORLDPART, FOG, AUTOPLANT, AUTOHARVEST, AUTOFARM, AUTOSTASH, AUTOBREED
    };
    private static final int[] DEFAULT_KEYS = {
            GLFW.GLFW_KEY_B, GLFW.GLFW_KEY_H, GLFW.GLFW_KEY_G, GLFW.GLFW_KEY_J, GLFW.GLFW_KEY_M, GLFW.GLFW_KEY_I,
            GLFW.GLFW_KEY_V, GLFW.GLFW_KEY_K, GLFW.GLFW_KEY_N, GLFW.GLFW_KEY_O, GLFW.GLFW_KEY_Y, GLFW.GLFW_KEY_L, GLFW.GLFW_KEY_P, GLFW.GLFW_KEY_X, GLFW.GLFW_KEY_Z, GLFW.GLFW_KEY_LEFT_BRACKET,
            GLFW.GLFW_KEY_KP_1, GLFW.GLFW_KEY_KP_2, GLFW.GLFW_KEY_KP_3, GLFW.GLFW_KEY_KP_4,
            GLFW.GLFW_KEY_KP_5, GLFW.GLFW_KEY_KP_6, GLFW.GLFW_KEY_KP_7, GLFW.GLFW_KEY_KP_8,
            GLFW.GLFW_KEY_KP_9, GLFW.GLFW_KEY_KP_0, GLFW.GLFW_KEY_KP_DECIMAL, GLFW.GLFW_KEY_KP_ADD, GLFW.GLFW_KEY_KP_SUBTRACT,
            GLFW.GLFW_KEY_KP_MULTIPLY, GLFW.GLFW_KEY_KP_DIVIDE, GLFW.GLFW_KEY_KP_ENTER, GLFW.GLFW_KEY_KP_EQUAL, GLFW.GLFW_KEY_F7,
            GLFW.GLFW_KEY_F8, GLFW.GLFW_KEY_F9, GLFW.GLFW_KEY_HOME, GLFW.GLFW_KEY_END, GLFW.GLFW_KEY_INSERT, GLFW.GLFW_KEY_PAGE_UP,
            GLFW.GLFW_KEY_PAGE_DOWN, GLFW.GLFW_KEY_DELETE, GLFW.GLFW_KEY_PAUSE,
            GLFW.GLFW_KEY_SCROLL_LOCK, GLFW.GLFW_KEY_NUM_LOCK
    };

    // ---- non-toggle keys ----
    private static KeyMapping kSwap;   // press: swap totem <-> shield in offhand
    private static KeyMapping kZoom;   // hold: zoom
    private static KeyMapping kMenu;   // Shift + Right Ctrl: open the menu

    // ore / block selection shared by AutoMine and Ore ESP (set in the menu)
    public static final java.util.Set<String> mineSet = new java.util.LinkedHashSet<>(java.util.List.of("diamond_ore"));
    public static String customQuery = "";
    private static BlockPos mineTarget = null;
    private static BlockPos mineDig = null;
    private static boolean mineWalking = false;
    private static boolean mineJump = false;
    private static final java.util.List<BlockPos> oreCache = new java.util.ArrayList<>();
    private static final int SCAN_RADIUS = 24;

    public static Module[] modules() {
        return MODULES;
    }

    // ---- internal state ----
    private static boolean nightVisionAdded = false;
    private static boolean flyWasOn = false;
    private static boolean sprintWasOn = false;
    private static boolean walkWasOn = false;
    private static boolean deathAnnounced = false;
    private static Integer savedFov = null;

    private static KeyMapping makeKey(String id, int glfwKey) {
        return KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.friendutil." + id, InputConstants.Type.KEYSYM, glfwKey, CATEGORY));
    }

    @Override
    public void onInitializeClient() {
        // Every key can be changed in Options -> Controls -> Key Binds -> "VoidDls".
        kSwap = makeKey("swap", GLFW.GLFW_KEY_R);
        kZoom = makeKey("zoom", GLFW.GLFW_KEY_C);
        kMenu = makeKey("menu", GLFW.GLFW_KEY_RIGHT_CONTROL);
        for (int i = 0; i < MODULES.length; i++) {
            MODULES[i].key = makeKey(MODULES[i].id, DEFAULT_KEYS[i]);
        }

        loadWarden();
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> !handleWardenCommand(msg));
        ClientTickEvents.END_CLIENT_TICK.register(FriendUtilClient::onTick);

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "hud"),
                (graphics, tickCounter) -> renderHud(graphics, tickCounter));
    }

    // ================================================================ tick

    private static void onTick(Minecraft mc) {
        for (Module m : MODULES) {
            while (m.key.consumeClick()) m.enabled = !m.enabled;
        }

        tickZoom(mc);

        while (kMenu.consumeClick()) {
            if (mc.gui.screen() == null && mc.options.keyShift.isDown()) mc.setScreenAndShow(new MenuScreen());
        }

        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null) {
            while (kSwap.consumeClick()) { /* ignore outside a world */ }
            return;
        }

        tickDeath(mc, p);

        while (kSwap.consumeClick()) {
            if (mc.gui.screen() == null) swapTotemShield(mc, p);
        }

        tickFullbright(p);
        tickFly(p);
        tickMovement(mc);

        if (AUTOTOTEM.enabled && mc.gui.screen() == null && p.tickCount % 2 == 0
                && !p.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
            swapOffhandWith(mc, p, Items.TOTEM_OF_UNDYING);
        }

        if (kaJumped) {                       // release the jump key pressed by KA Crits last tick
            mc.options.keyJump.setDown(false);
            kaJumped = false;
        }
        if ((KILLAURA.enabled || MOBAURA.enabled) && mc.gui.screen() == null) tickKillAura(mc, p, !KILLAURA.enabled);
        if (TRIGGERBOT.enabled && mc.gui.screen() == null) tickTriggerBot(mc, p);
        if (AIMASSIST.enabled && mc.gui.screen() == null) tickAimAssist(mc, p);
        tickMoveHacks(mc, p);
        tickAutoGapple(mc, p);
        tickAutoEat(mc, p);
        tickAutoTool(mc, p);
        tickAutoFish(mc, p);
        tickAutoPlant(mc, p);
        tickAutoHarvest(mc, p);
        tickAutoFarm(mc, p);
        tickAutoStash(mc, p);
        tickAutoBreed(mc, p);
        tickVisuals(mc, p);
        tickShapes(mc, p);
        if (!tickWardenRoute(mc, p)) tickAutoWarden(mc, p);

        if (ORE_ESP.enabled || AUTOMINE.enabled) refreshMatchCache();
        if ((ORE_ESP.enabled || AUTOMINE.enabled) && p.tickCount % 20 == 0 && !matchCache.isEmpty()) scanOres(mc, p);
        if (AUTOMINE.enabled && mc.gui.screen() == null) tickAutoMine(mc, p);
        else releaseMine(mc);

        if (ANTIAFK.enabled && p.tickCount % 1200 == 0) {
            p.swing(InteractionHand.MAIN_HAND);
            p.setYRot(p.getYRot() + 3.0f);
        }
    }

    // KillAura: smooth aim at the best target, then a normal hit when the crosshair is on it.
    private static final double KA_AIM_RANGE = 4.5;     // start turning toward targets this close
    private static final double KA_HIT_RANGE = 3.0;     // vanilla survival reach
    private static final float  KA_MAX_TURN  = 28.0f;   // max degrees per tick
    private static final float  KA_HIT_ANGLE = 6.0f;    // max aim error to allow a hit
    private static final java.util.Random KA_RNG = new java.util.Random();
    private static final float  KA_SMOOTH_TURN = 14.0f;   // max degrees per tick while smoothing
    private static float kaVelYaw = 0.0f, kaVelPitch = 0.0f;
    private static boolean kaJumped = false;

    private static void tickKillAura(Minecraft mc, LocalPlayer p, boolean mobsOnly) {
        if (mc.level == null || !p.isAlive() || p.isSpectator()) return;

        Vec3 eye = p.getEyePosition();
        Entity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity e : mc.level.getEntities(p, p.getBoundingBox().inflate(KA_AIM_RANGE),
                en -> en instanceof LivingEntity le && le.isAlive()
                        && (en instanceof Enemy || (!mobsOnly && en instanceof Player)))) {
            if (e.isSpectator() || e.isInvisible() || !p.hasLineOfSight(e)) continue;
            if (eyeDistance(eye, e) > KA_AIM_RANGE) continue;
            Vec3 aim = aimPoint(e);
            double err = Math.abs(Mth.wrapDegrees(yawTo(eye, aim) - p.getYRot()))
                    + Math.abs(Mth.wrapDegrees(pitchTo(eye, aim) - p.getXRot()));
            double score = err + eyeDistance(eye, e) * 4.0;   // prefer targets near the crosshair
            if (score < bestScore) {
                bestScore = score;
                best = e;
            }
        }
        if (best == null) {
            kaVelYaw = 0.0f;
            kaVelPitch = 0.0f;
            return;
        }

        // smooth turn: ease toward the target (30% of the remaining angle), low-pass filtered so the aim
        // accelerates and decelerates instead of snapping, with a tiny noise
        Vec3 aim = aimPoint(best);
        float dyaw = Mth.wrapDegrees(yawTo(eye, aim) - p.getYRot());
        float dpitch = Mth.wrapDegrees(pitchTo(eye, aim) - p.getXRot());
        float wantYaw = Mth.clamp(dyaw * 0.3f, -KA_SMOOTH_TURN, KA_SMOOTH_TURN);
        float wantPitch = Mth.clamp(dpitch * 0.3f, -KA_SMOOTH_TURN * 0.6f, KA_SMOOTH_TURN * 0.6f);
        kaVelYaw += (wantYaw - kaVelYaw) * 0.45f;
        kaVelPitch += (wantPitch - kaVelPitch) * 0.45f;
        p.setYRot(p.getYRot() + kaVelYaw + (KA_RNG.nextFloat() - 0.5f) * 0.3f);
        p.setXRot(Mth.clamp(p.getXRot() + kaVelPitch + (KA_RNG.nextFloat() - 0.5f) * 0.2f, -90.0f, 90.0f));

        // hit only with a full cooldown, in reach, and when actually aimed at the target
        if (p.getAttackStrengthScale(0.5f) < 1.0f) return;
        if (eyeDistance(eye, best) > KA_HIT_RANGE) return;
        float errYaw = Math.abs(Mth.wrapDegrees(yawTo(eye, aim) - p.getYRot()));
        float errPitch = Math.abs(Mth.wrapDegrees(pitchTo(eye, aim) - p.getXRot()));
        if (errYaw > KA_HIT_ANGLE || errPitch > KA_HIT_ANGLE) return;

        // KA Crits: jump, then hit while falling. A sprinting hit can't be critical, so stop sprinting first.
        if (KA_CRITS.enabled && critPossible(p)) {
            if (p.onGround()) {
                mc.options.keyJump.setDown(true);
                kaJumped = true;
                return;
            }
            if (!(p.fallDistance > 0.0 && p.getDeltaMovement().y < 0.0)) return;   // wait until falling
            p.setSprinting(false);
        }

        mc.gameMode.attack(p, best);
        p.swing(InteractionHand.MAIN_HAND);
    }

    private static boolean critPossible(LocalPlayer p) {
        return !p.isInWater() && !p.isInLava() && !p.onClimbable() && !p.isPassenger()
                && !p.hasEffect(MobEffects.BLINDNESS) && !p.getAbilities().flying;
    }

    // ---------------------------------------------------------------- block search / AutoMine / Ore ESP

    // Matching blocks are resolved once per selection change (not per scanned block) - the scan covers ~117k blocks.
    private static final java.util.Set<net.minecraft.world.level.block.Block> matchCache = new java.util.HashSet<>();
    private static String matchKey = null;

    private static void refreshMatchCache() {
        String c = customQuery == null ? "" : customQuery.trim().toLowerCase();
        String key = String.join(",", mineSet) + "|" + c;
        if (key.equals(matchKey)) return;
        matchKey = key;
        matchCache.clear();
        for (net.minecraft.world.level.block.Block b : BuiltInRegistries.BLOCK) {
            String id = BuiltInRegistries.BLOCK.getKey(b).getPath();
            boolean hit = !c.isEmpty() && id.contains(c);
            for (String k : mineSet) {
                if (hit) break;
                hit = id.contains(k);
            }
            if (hit) matchCache.add(b);
        }
    }

    private static boolean matches(BlockState st) {
        return !matchCache.isEmpty() && matchCache.contains(st.getBlock());
    }

    private static void scanOres(Minecraft mc, LocalPlayer p) {
        oreCache.clear();
        if (mc.level == null) return;
        BlockPos c = p.blockPosition();
        int r = SCAN_RADIUS;
        for (BlockPos pos : BlockPos.betweenClosed(c.offset(-r, -r, -r), c.offset(r, r, r))) {
            if (matches(mc.level.getBlockState(pos))) {
                oreCache.add(pos.immutable());
                if (oreCache.size() >= 400) break;
            }
        }
        oreCache.sort(java.util.Comparator.comparingDouble(b -> b.distSqr(c)));
    }

    private static void releaseMine(Minecraft mc) {
        if (mineWalking) {
            mc.options.keyUp.setDown(false);
            mineWalking = false;
        }
        if (mineJump) {
            mc.options.keyJump.setDown(false);
            mineJump = false;
        }
        mineTarget = null;
        mineDig = null;
    }

    // AutoMine: picks the nearest selected block, walks to it (digging through anything in the way) and mines it.
    private static void tickAutoMine(Minecraft mc, LocalPlayer p) {
        if (mineJump) {                                   // release the jump pressed last tick
            mc.options.keyJump.setDown(false);
            mineJump = false;
        }
        if (mc.level == null || !p.isAlive() || p.isSpectator()) {
            releaseMine(mc);
            return;
        }
        if (p.getHealth() <= 6.0f) {                      // safety stop
            AUTOMINE.enabled = false;
            releaseMine(mc);
            p.sendSystemMessage(Component.literal("[VoidDls] AutoMine stopped: low health"));
            return;
        }

        if (mineTarget != null && !matches(mc.level.getBlockState(mineTarget))) mineTarget = null;
        if (mineTarget == null) {
            for (BlockPos pos : oreCache) {
                if (matches(mc.level.getBlockState(pos))) {
                    mineTarget = pos;
                    break;
                }
            }
        }
        if (mineTarget == null) {                         // nothing found in range
            if (mineWalking) {
                mc.options.keyUp.setDown(false);
                mineWalking = false;
            }
            return;
        }

        Vec3 eye = p.getEyePosition();
        Vec3 tc = Vec3.atCenterOf(mineTarget);
        double dist = eye.distanceTo(tc);

        // first solid block on the way to the target is what we dig next
        BlockPos dig = mineTarget;
        Vec3 dir = tc.subtract(eye).normalize();
        for (double t = 0.6; t < dist; t += 0.25) {
            Vec3 pt = eye.add(dir.scale(t));
            BlockPos bp = BlockPos.containing(pt.x, pt.y, pt.z);
            if (bp.equals(mineTarget)) break;
            BlockState st = mc.level.getBlockState(bp);
            if (!st.isAir() && st.getFluidState().isEmpty()) {
                dig = bp;
                break;
            }
        }
        if (mc.level.getBlockState(dig).getDestroySpeed(mc.level, dig) < 0.0f) {   // unbreakable (bedrock etc.)
            mineTarget = null;
            return;
        }

        Vec3 dc = Vec3.atCenterOf(dig);
        float dyaw = Mth.wrapDegrees(yawTo(eye, dc) - p.getYRot());
        float dpitch = Mth.wrapDegrees(pitchTo(eye, dc) - p.getXRot());
        p.setYRot(p.getYRot() + Mth.clamp(dyaw * 0.6f, -KA_MAX_TURN, KA_MAX_TURN));
        p.setXRot(Mth.clamp(p.getXRot() + Mth.clamp(dpitch * 0.6f, -KA_MAX_TURN, KA_MAX_TURN), -90.0f, 90.0f));

        if (eye.distanceTo(dc) > 3.4) {                   // too far: walk closer
            mc.options.keyUp.setDown(true);
            mineWalking = true;
            if (p.horizontalCollision && p.onGround()) {
                mc.options.keyJump.setDown(true);
                mineJump = true;
            }
        } else {                                          // in reach: stop and dig
            if (mineWalking) {
                mc.options.keyUp.setDown(false);
                mineWalking = false;
            }
            selectBestTool(p, mc.level.getBlockState(dig));
            Direction face = Direction.getApproximateNearest(eye.x - dc.x, eye.y - dc.y, eye.z - dc.z);
            if (!dig.equals(mineDig)) {
                mc.gameMode.startDestroyBlock(dig, face);
                mineDig = dig;
            } else {
                mc.gameMode.continueDestroyBlock(dig, face);
            }
            p.swing(InteractionHand.MAIN_HAND);
        }
    }

    // Ore ESP: tints the selected blocks with a translucent overlay + outline, visible through walls (no text).
    private static final class OreHit {
        final BlockPos pos;
        final int color;
        final double dist;

        OreHit(BlockPos pos, int color, double dist) {
            this.pos = pos;
            this.color = color;
            this.dist = dist;
        }
    }

    // The face of a block that looks toward the player (used for the Fill stripes).
    private static Direction faceToward(Vec3 eye, BlockPos p) {
        double dx = eye.x - (p.getX() + 0.5), dy = eye.y - (p.getY() + 0.5), dz = eye.z - (p.getZ() + 0.5);
        double ax = Math.abs(dx), ay = Math.abs(dy), az = Math.abs(dz);
        if (ay >= ax && ay >= az) return dy > 0 ? Direction.UP : Direction.DOWN;
        if (ax >= az) return dx > 0 ? Direction.EAST : Direction.WEST;
        return dz > 0 ? Direction.SOUTH : Direction.NORTH;
    }

    // Ore ESP drawn with the BlockOverlay look: a cube outline (and optional fill stripes) around every ore, in the ore's color.
    // Drawing is per pixel, so only the nearest ores are drawn and only the nearest few get the fill.
    // Ore ESP (Player ESP style): a 2D outline around every selected ore, projected by hand, visible through walls.
    // Only 4 rectangles per ore, so it is cheap; the 120 nearest are drawn.
    private static void renderOreEsp(GuiGraphics graphics, Minecraft mc, LocalPlayer self, Font font, float pt) {
        if (mc.level == null || oreCache.isEmpty()) return;

        Cam cam = makeCam(mc, self, pt);
        List<BlockPos> near = new ArrayList<>();
        for (BlockPos pos : oreCache) {
            if (matches(mc.level.getBlockState(pos))) near.add(pos);
        }
        near.sort(java.util.Comparator.comparingDouble(pp -> cam.eye.distanceToSqr(Vec3.atCenterOf(pp))));
        int shown = 0;
        for (BlockPos pos : near) {
            if (shown >= 120) break;
            int[] b = screenBox(new net.minecraft.world.phys.AABB(pos), cam.eye, cam.fwd, cam.right, cam.up,
                    cam.tanHalf, cam.aspect, cam.sw, cam.sh);
            if (b == null || b[2] < 0 || b[0] > cam.sw || b[3] < 0 || b[1] > cam.sh) continue;
            if (b[2] - b[0] < 4) {                                         // far away: keep it visible
                int cx = (b[0] + b[2]) / 2;
                b[0] = cx - 2;
                b[2] = cx + 2;
            }
            if (b[3] - b[1] < 4) {
                int cy = (b[1] + b[3]) / 2;
                b[1] = cy - 2;
                b[3] = cy + 2;
            }
            String id = BuiltInRegistries.BLOCK.getKey(mc.level.getBlockState(pos).getBlock()).getPath();
            outline(graphics, b[0] - 1, b[1] - 1, b[2] + 1, b[3] + 1, 0xFF000000);   // dark outer edge
            outline(graphics, b[0], b[1], b[2], b[3], oreColor(id));
            shown++;
        }
    }

    private static void outline(GuiGraphics g, int x1, int y1, int x2, int y2, int c) {
        g.fill(x1, y1, x2, y1 + 1, c);
        g.fill(x1, y2 - 1, x2, y2, c);
        g.fill(x1, y1 + 1, x1 + 1, y2 - 1, c);
        g.fill(x2 - 1, y1 + 1, x2, y2 - 1, c);
    }

    // screen-space rectangle {minX, minY, maxX, maxY} around the 8 projected corners of a box, or null if it is not fully in front of the camera
    private static int[] screenBox(net.minecraft.world.phys.AABB bb, Vec3 eye, Vec3 fwd, Vec3 right, Vec3 up,
                                   double tanHalf, double aspect, int sw, int sh) {
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE;
        for (int i = 0; i < 8; i++) {
            Vec3 c = new Vec3((i & 1) == 0 ? bb.minX : bb.maxX, (i & 2) == 0 ? bb.minY : bb.maxY, (i & 4) == 0 ? bb.minZ : bb.maxZ);
            int[] s = project(c, eye, fwd, right, up, tanHalf, aspect, sw, sh);
            if (s == null) return null;
            minX = Math.min(minX, s[0]);
            minY = Math.min(minY, s[1]);
            maxX = Math.max(maxX, s[0]);
            maxY = Math.max(maxY, s[1]);
        }
        return new int[]{minX, minY, maxX, maxY};
    }

    private static int oreColor(String id) {
        if (id.contains("diamond")) return 0xFF55FFFF;
        if (id.contains("emerald")) return 0xFF55FF55;
        if (id.contains("gold")) return 0xFFFFFF55;
        if (id.contains("iron")) return 0xFFFFAA77;
        if (id.contains("copper")) return 0xFFFF8844;
        if (id.contains("redstone")) return 0xFFFF5555;
        if (id.contains("lapis")) return 0xFF5577FF;
        if (id.contains("quartz")) return 0xFFFFFFFF;
        if (id.contains("debris")) return 0xFFBB8855;
        if (id.contains("coal")) return 0xFFAAAAAA;
        return 0xFFFFFFFF;
    }

    // ---------------------------------------------------------------- AutoWarden
    // Loots chests that show a countdown hologram (e.g. Ancient City chests on servers that refill them on a timer):
    // finds chests with a timer above them, walks to the one that refills first, opens it when the timer reaches
    // `wardenOpenAt` seconds and shift-clicks everything into the inventory. Straight-line walking, no pathfinding.
    public static int wardenOpenAt = 2;
    private static final java.util.List<BlockPos> wardenChests = new java.util.ArrayList<>();
    private static final java.util.Map<BlockPos, Integer> wardenDone = new java.util.HashMap<>();
    private static final java.util.regex.Pattern T_HMS = java.util.regex.Pattern.compile("(\\d+):(\\d{2}):(\\d{2})");
    private static final java.util.regex.Pattern T_MS = java.util.regex.Pattern.compile("(\\d+):(\\d{2})");
    private static final java.util.regex.Pattern T_MIN = java.util.regex.Pattern.compile("(\\d+)\\s*(?:мин|min|m)");
    private static final java.util.regex.Pattern T_SEC = java.util.regex.Pattern.compile("(\\d+)\\s*(?:сек|sec|s|с)");
    private static BlockPos wardenTarget = null;
    private static boolean wardenWalking = false;
    private static boolean wardenJump = false;
    private static int wardenTick = 0;
    private static int wardenOpenCd = 0;
    private static int wardenLootTicks = 0;
    private static BlockPos wardenPathTo = null;
    private static int wardenPathCd = 0;
    private static Boolean baritoneFound = null;

    // Baritone is optional: if its jar is in the mods folder, AutoWarden drives it with "#goto" chat commands.
    private static boolean baritoneAvailable() {
        if (baritoneFound == null) {
            try {
                Class.forName("baritone.api.BaritoneAPI");
                baritoneFound = true;
            } catch (Throwable t) {
                baritoneFound = false;
            }
        }
        return baritoneFound;
    }

    // a free block next to the chest to stand on (a chest itself is not a valid path goal)
    private static BlockPos standPos(Minecraft mc, BlockPos chest) {
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos s = chest.relative(d);
            if (mc.level.getBlockState(s).isAir() && mc.level.getBlockState(s.above()).isAir()
                    && !mc.level.getBlockState(s.below()).isAir()) return s;
        }
        return chest;
    }

    private static int parseTimerSeconds(String raw) {
        String t = raw.replaceAll("\u00a7.", "").toLowerCase();
        java.util.regex.Matcher m = T_HMS.matcher(t);
        if (m.find()) return Integer.parseInt(m.group(1)) * 3600 + Integer.parseInt(m.group(2)) * 60 + Integer.parseInt(m.group(3));
        m = T_MS.matcher(t);
        if (m.find()) return Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(2));
        int total = -1;
        m = T_MIN.matcher(t);
        if (m.find()) total = Integer.parseInt(m.group(1)) * 60;
        m = T_SEC.matcher(t);
        if (m.find()) total = Math.max(total, 0) + Integer.parseInt(m.group(1));
        return total;
    }

    // seconds shown by the hologram around the chest, or -1 if there is none
    private static int chestTimer(Minecraft mc, LocalPlayer p, BlockPos pos) {
        net.minecraft.world.phys.AABB box = new net.minecraft.world.phys.AABB(pos).inflate(1.5, 2.5, 1.5);
        int best = -1;
        for (Entity e : mc.level.getEntities(p, box, en -> en.hasCustomName())) {
            Component name = e.getCustomName();
            if (name == null) continue;
            int sec = parseTimerSeconds(name.getString());
            if (sec >= 0 && (best < 0 || sec < best)) best = sec;
        }
        return best;
    }

    private static void scanChests(Minecraft mc, LocalPlayer p) {
        wardenChests.clear();
        BlockPos c = p.blockPosition();
        for (BlockPos pos : BlockPos.betweenClosed(c.offset(-32, -8, -32), c.offset(32, 8, 32))) {
            if (mc.level.getBlockState(pos).getBlock() instanceof net.minecraft.world.level.block.ChestBlock) {
                wardenChests.add(pos.immutable());
            }
        }
    }

    private static void releaseWarden(Minecraft mc) {
        if (wardenPathTo != null && mc.player != null) {
            mc.player.connection.sendChat("#stop");
            wardenPathTo = null;
        }
        if (wardenWalking) {
            mc.options.keyUp.setDown(false);
            wardenWalking = false;
        }
        if (wardenJump) {
            mc.options.keyJump.setDown(false);
            wardenJump = false;
        }
        wardenTarget = null;
    }

    private static void tickAutoWarden(Minecraft mc, LocalPlayer p) {
        if (!AUTOWARDEN.enabled || mc.level == null || !p.isAlive() || p.isSpectator()) {
            releaseWarden(mc);
            return;
        }
        wardenTick++;
        if (wardenOpenCd > 0) wardenOpenCd--;
        if (wardenPathCd > 0) wardenPathCd--;
        if (wardenJump) {
            mc.options.keyJump.setDown(false);
            wardenJump = false;
        }
        if (p.getHealth() <= 6.0f) {                                 // safety stop
            AUTOWARDEN.enabled = false;
            releaseWarden(mc);
            p.sendSystemMessage(Component.literal("[VoidDls] AutoWarden stopped: low health"));
            return;
        }

        // a chest we opened: take everything
        if (mc.gui.screen() instanceof net.minecraft.client.gui.screens.inventory.AbstractContainerScreen<?>) {
            if (wardenTarget != null) lootOpenChest(mc, p);
            return;
        }
        if (mc.gui.screen() != null) return;
        wardenLootTicks = 0;

        if (wardenTick % 20 == 1) {
            scanChests(mc, p);
            learnChests(mc, p);
        }

        BlockPos best = null;
        int bestTimer = Integer.MAX_VALUE;
        for (BlockPos pos : wardenChests) {
            Integer until = wardenDone.get(pos);
            if (until != null && until > wardenTick) continue;       // looted recently
            int t = chestTimer(mc, p, pos);
            if (t < 0 || t > 120) continue;                          // no timer, or too far in the future
            if (t < bestTimer) {
                bestTimer = t;
                best = pos;
            }
        }
        if (best == null) {
            if (wardenPhase == 5 && roamToSaved(mc, p)) return;      // head for a saved chest that is out of render range
            wardenIdle++;
            releaseWarden(mc);
            return;
        }
        wardenIdle = 0;
        wardenTarget = best;

        Vec3 eye = p.getEyePosition();
        Vec3 tc = Vec3.atCenterOf(best);
        boolean far = eye.distanceTo(tc) > 3.8;

        if (far && baritoneAvailable()) {                            // let Baritone find the way
            if (!best.equals(wardenPathTo) || wardenPathCd == 0) {
                BlockPos g = standPos(mc, best);
                p.connection.sendChat("#goto " + g.getX() + " " + g.getY() + " " + g.getZ());
                wardenPathTo = best;
                wardenPathCd = 100;
            }
            return;
        }
        if (wardenPathTo != null) {                                  // arrived: stop Baritone
            p.connection.sendChat("#stop");
            wardenPathTo = null;
        }

        float dyaw = Mth.wrapDegrees(yawTo(eye, tc) - p.getYRot());
        float dpitch = Mth.wrapDegrees(pitchTo(eye, tc) - p.getXRot());
        p.setYRot(p.getYRot() + Mth.clamp(dyaw * 0.6f, -KA_MAX_TURN, KA_MAX_TURN));
        p.setXRot(Mth.clamp(p.getXRot() + Mth.clamp(dpitch * 0.6f, -KA_MAX_TURN, KA_MAX_TURN), -90.0f, 90.0f));

        if (far) {                                                   // no Baritone: walk straight at it
            mc.options.keyUp.setDown(true);
            wardenWalking = true;
            if (p.horizontalCollision && p.onGround()) {
                mc.options.keyJump.setDown(true);
                wardenJump = true;
            }
            return;
        }
        if (wardenWalking) {
            mc.options.keyUp.setDown(false);
            wardenWalking = false;
        }
        if (bestTimer <= wardenOpenAt && wardenOpenCd == 0) {        // timer is up: open
            Direction face = Direction.getApproximateNearest(eye.x - tc.x, eye.y - tc.y, eye.z - tc.z);
            mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND,
                    new net.minecraft.world.phys.BlockHitResult(tc, face, best, false));
            p.swing(InteractionHand.MAIN_HAND);
            wardenOpenCd = 10;
        }
    }

    private static void lootOpenChest(Minecraft mc, LocalPlayer p) {
        net.minecraft.world.inventory.AbstractContainerMenu menu = p.containerMenu;
        int chestSlots = menu.slots.size() - 36;                     // the rest is the player inventory
        int moved = 0;
        boolean any = false;
        for (int i = 0; i < chestSlots; i++) {
            if (!menu.getSlot(i).hasItem()) continue;
            any = true;
            if (moved < 3) {
                mc.gameMode.handleInventoryMouseClick(menu.containerId, i, 0, ClickType.QUICK_MOVE, p);
                moved++;
            }
        }
        wardenLootTicks++;
        if (!any || wardenLootTicks > 60) {                          // empty (or inventory is full): close and move on
            p.closeContainer();
            if (wardenTarget != null) wardenDone.put(wardenTarget, wardenTick + 600);
            wardenTarget = null;
            wardenLootTicks = 0;
        }
    }

    // ---------------------------------------------------------------- AutoWarden route (anarchies)
    // Chat commands (typed with a dot, never sent to the server):
    //   .add warden 206 / .del warden 206      edit the anarchy queue
    //   .warden list | clear | start | stop     show / empty / begin / end the route
    //   .warden scan 206                        remember the timer chests around you for anarchy 206
    //   .warden base <cmd>                      command that teleports to your base (default "home")
    //   .warden an <fmt>                        anarchy command format (default "an%d" -> /an206)
    // With a queue AutoWarden loops per anarchy: base -> drink Invisibility + Speed (hotbar potions) -> anarchy ->
    // loot timer chests (saved chest positions are visited too) -> next anarchy -> back to base.
    public static String wardenBaseCmd = "home";
    public static String wardenAnFmt = "an%d";
    private static final java.util.List<Integer> wardenQueue = new java.util.ArrayList<>();
    private static final java.util.Map<Integer, java.util.List<BlockPos>> wardenSaved = new java.util.HashMap<>();
    private static final java.nio.file.Path WARDEN_FILE =
            net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("voiddls_warden.txt");
    private static int wardenPhase = 0;      // 0 to base, 1 wait, 2 potions, 3 to anarchy, 4 wait, 5 looting
    private static int wardenWait = 0;
    private static int wardenIdx = 0;
    private static int wardenIdle = 0;
    private static int wardenBuffTicks = 0;
    private static int wardenBuffRestore = -1;

    public static int wardenQueueSize() {
        return wardenQueue.size();
    }

    private static void say(String m) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.sendSystemMessage(Component.literal("[VoidDls] " + m));
    }

    private static void loadWarden() {
        try {
            if (!java.nio.file.Files.exists(WARDEN_FILE)) return;
            for (String line : java.nio.file.Files.readAllLines(WARDEN_FILE)) {
                String[] a = line.trim().split("\\s+", 2);
                if (a.length < 2) continue;
                switch (a[0]) {
                    case "BASE" -> wardenBaseCmd = a[1];
                    case "FMT" -> wardenAnFmt = a[1];
                    case "Q" -> wardenQueue.add(Integer.parseInt(a[1].trim()));
                    default -> {
                        String[] c = line.trim().split("\\s+");
                        if (c.length == 4) {
                            wardenSaved.computeIfAbsent(Integer.parseInt(c[0]), k -> new ArrayList<>())
                                    .add(new BlockPos(Integer.parseInt(c[1]), Integer.parseInt(c[2]), Integer.parseInt(c[3])));
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    private static void saveWarden() {
        try {
            List<String> out = new ArrayList<>();
            out.add("BASE " + wardenBaseCmd);
            out.add("FMT " + wardenAnFmt);
            for (int n : wardenQueue) out.add("Q " + n);
            for (var e : wardenSaved.entrySet()) {
                for (BlockPos b : e.getValue()) out.add(e.getKey() + " " + b.getX() + " " + b.getY() + " " + b.getZ());
            }
            java.nio.file.Files.write(WARDEN_FILE, out);
        } catch (Exception ignored) {
        }
    }

    private static boolean handleWardenCommand(String msg) {
        if (!msg.startsWith(".")) return false;
        String[] a = msg.trim().split("\\s+");
        String c = a[0].toLowerCase();
        boolean add = c.equals(".add") && a.length >= 3 && a[1].equalsIgnoreCase("warden");
        boolean del = c.equals(".del") && a.length >= 3 && a[1].equalsIgnoreCase("warden");
        boolean cmd = c.equals(".warden");
        if (!add && !del && !cmd) return false;
        Minecraft mc = Minecraft.getInstance();
        try {
            if (add || del) {
                int n = Integer.parseInt(a[2]);
                if (add) {
                    if (!wardenQueue.contains(n)) wardenQueue.add(n);
                    say("anarchy " + n + " added, queue: " + wardenQueue);
                } else {
                    wardenQueue.remove(Integer.valueOf(n));
                    wardenIdx = 0;
                    say("anarchy " + n + " removed, queue: " + wardenQueue);
                }
            } else if (a.length < 2) {
                say(".add warden <n> | .del warden <n> | .warden list/clear/start/stop/scan <n>/base <cmd>/an <fmt>");
            } else {
                switch (a[1].toLowerCase()) {
                    case "list" -> {
                        StringBuilder sb = new StringBuilder("queue " + wardenQueue + ", base /" + wardenBaseCmd
                                + ", format /" + wardenAnFmt + ", saved chests:");
                        for (var e : wardenSaved.entrySet()) sb.append(' ').append(e.getKey()).append('=').append(e.getValue().size());
                        say(sb.toString());
                    }
                    case "clear" -> {
                        wardenQueue.clear();
                        wardenIdx = 0;
                        say("queue cleared");
                    }
                    case "start" -> {
                        if (wardenQueue.isEmpty()) {
                            say("queue is empty: .add warden <n>");
                        } else {
                            wardenIdx = 0;
                            wardenPhase = 0;
                            AUTOWARDEN.enabled = true;
                            say("route started: " + wardenQueue);
                        }
                    }
                    case "stop" -> {
                        AUTOWARDEN.enabled = false;
                        say("AutoWarden stopped");
                    }
                    case "scan" -> {
                        int n = Integer.parseInt(a[2]);
                        if (mc.player == null || mc.level == null) return true;
                        scanChests(mc, mc.player);
                        int added = rememberChests(mc, mc.player, n);
                        say("anarchy " + n + ": saved " + added + " new timer chests");
                    }
                    case "base" -> {
                        wardenBaseCmd = msg.trim().substring(msg.trim().toLowerCase().indexOf("base") + 4).trim();
                        say("base command: /" + wardenBaseCmd);
                    }
                    case "an" -> {
                        String fmt = a[2];
                        if (!fmt.contains("%d")) {
                            say("format must contain %d, e.g. an%d");
                        } else {
                            wardenAnFmt = fmt;
                            say("anarchy command: /" + fmt.replace("%d", "206"));
                        }
                    }
                    default -> say("unknown subcommand");
                }
            }
            saveWarden();
        } catch (Exception ex) {
            say("bad arguments");
        }
        return true;
    }

    private static int rememberChests(Minecraft mc, LocalPlayer p, int anarchy) {
        List<BlockPos> saved = wardenSaved.computeIfAbsent(anarchy, k -> new ArrayList<>());
        int added = 0;
        for (BlockPos pos : wardenChests) {
            if (chestTimer(mc, p, pos) >= 0 && !saved.contains(pos)) {
                saved.add(pos);
                added++;
            }
        }
        if (added > 0) saveWarden();
        return added;
    }

    private static void learnChests(Minecraft mc, LocalPlayer p) {
        if (wardenPhase == 5 && !wardenQueue.isEmpty()) rememberChests(mc, p, wardenQueue.get(wardenIdx));
    }

    // walk toward the nearest saved chest of this anarchy that has not been visited (its timer is out of render range)
    private static boolean roamToSaved(Minecraft mc, LocalPlayer p) {
        List<BlockPos> saved = wardenSaved.get(wardenQueue.get(wardenIdx));
        if (saved == null) return false;
        BlockPos near = null;
        double bd = Double.MAX_VALUE;
        for (BlockPos pos : saved) {
            Integer until = wardenDone.get(pos);
            if (until != null && until > wardenTick) continue;
            double d = pos.distSqr(p.blockPosition());
            if (d < bd) {
                bd = d;
                near = pos;
            }
        }
        if (near == null) return false;
        if (bd < 12 * 12) {                                          // close enough to see its timer: mark as visited
            wardenDone.put(near, wardenTick + 1200);
            return true;
        }
        if (baritoneAvailable()) {
            if (!near.equals(wardenPathTo) || wardenPathCd == 0) {
                p.connection.sendChat("#goto " + near.getX() + " " + near.getY() + " " + near.getZ());
                wardenPathTo = near;
                wardenPathCd = 100;
            }
            return true;
        }
        Vec3 eye = p.getEyePosition();
        Vec3 tc = Vec3.atCenterOf(near);
        float dyaw = Mth.wrapDegrees(yawTo(eye, tc) - p.getYRot());
        p.setYRot(p.getYRot() + Mth.clamp(dyaw * 0.6f, -KA_MAX_TURN, KA_MAX_TURN));
        mc.options.keyUp.setDown(true);
        wardenWalking = true;
        if (p.horizontalCollision && p.onGround()) {
            mc.options.keyJump.setDown(true);
            wardenJump = true;
        }
        return true;
    }

    private static int findHotbarPotion(Inventory inv, String... names) {
        for (int i = 0; i < 9; i++) {
            ItemStack st = inv.getItem(i);
            if (!st.is(Items.POTION)) continue;
            String n = st.getHoverName().getString().toLowerCase();
            for (String k : names) {
                if (n.contains(k)) return i;
            }
        }
        return -1;
    }

    private static void tickWardenBuff(Minecraft mc, LocalPlayer p) {
        wardenBuffTicks++;
        Inventory inv = p.getInventory();
        int slot = -1;
        if (!p.hasEffect(MobEffects.INVISIBILITY)) slot = findHotbarPotion(inv, "невидим", "invisib");
        if (slot < 0 && !p.hasEffect(MobEffects.SPEED)) slot = findHotbarPotion(inv, "скор", "swift", "speed");
        if (slot < 0 || wardenBuffTicks > 240) {                     // all active (or no potions left): go
            mc.options.keyUse.setDown(false);
            if (wardenBuffRestore >= 0) inv.setSelectedSlot(wardenBuffRestore);
            wardenBuffRestore = -1;
            wardenPhase = 3;
            return;
        }
        if (wardenBuffRestore < 0) wardenBuffRestore = inv.getSelectedSlot();
        if (inv.getSelectedSlot() != slot) inv.setSelectedSlot(slot);
        mc.options.keyUse.setDown(true);
    }

    private static void wardenStopRoute(Minecraft mc, LocalPlayer p) {
        if (wardenPhase == 2) {
            mc.options.keyUse.setDown(false);
            if (wardenBuffRestore >= 0) p.getInventory().setSelectedSlot(wardenBuffRestore);
            wardenBuffRestore = -1;
        }
        wardenPhase = 0;
    }

    // returns true while the route is busy teleporting / drinking (the chest logic must not run then)
    private static boolean tickWardenRoute(Minecraft mc, LocalPlayer p) {
        if (!AUTOWARDEN.enabled || wardenQueue.isEmpty()) {
            if (wardenPhase != 0) wardenStopRoute(mc, p);
            return false;
        }
        if (wardenIdx >= wardenQueue.size()) wardenIdx = 0;
        switch (wardenPhase) {
            case 0 -> {
                releaseWarden(mc);
                p.connection.sendCommand(wardenBaseCmd);
                wardenWait = 80;
                wardenBuffTicks = 0;
                wardenPhase = 1;
                return true;
            }
            case 1 -> {
                if (--wardenWait <= 0) wardenPhase = 2;
                return true;
            }
            case 2 -> {
                tickWardenBuff(mc, p);
                return true;
            }
            case 3 -> {
                p.connection.sendCommand(String.format(wardenAnFmt, wardenQueue.get(wardenIdx)));
                wardenWait = 100;
                wardenPhase = 4;
                return true;
            }
            case 4 -> {
                if (--wardenWait <= 0) {
                    wardenPhase = 5;
                    wardenIdle = 0;
                }
                return true;
            }
            default -> {
                boolean full = true;
                for (int i = 0; i < 36 && full; i++) full = !p.getInventory().getItem(i).isEmpty();
                if (wardenIdle > 1200 || full) {                     // nothing left here (1 min idle) or inventory full
                    releaseWarden(mc);
                    wardenIdx++;
                    wardenPhase = 0;
                    if (wardenIdx >= wardenQueue.size()) {           // route finished: back to base
                        wardenIdx = 0;
                        p.connection.sendCommand(wardenBaseCmd);
                        AUTOWARDEN.enabled = false;
                        say("AutoWarden route finished" + (full ? " (inventory full)" : ""));
                    }
                    return true;
                }
                return false;
            }
        }
    }

    // ---------------------------------------------------------------- Trajectory
    // Predicts the flight of the item in your hand: bow (while drawn), loaded crossbow, trident (while charged),
    // ender pearl, snowball, egg. Vanilla speed / gravity / drag, stops at the first block. Mobs are not checked.
    private record Launch(double speed, double gravity, double drag) {}

    private static Launch launchFor(LocalPlayer p) {
        for (InteractionHand h : new InteractionHand[]{InteractionHand.MAIN_HAND, InteractionHand.OFF_HAND}) {
            ItemStack st = p.getItemInHand(h);
            if (st.is(Items.BOW)) {
                if (!p.isUsingItem() || p.getUsedItemHand() != h) return null;
                float f = p.getTicksUsingItem() / 20.0f;
                f = (f * f + f * 2.0f) / 3.0f;
                if (f < 0.1f) return null;
                return new Launch(Math.min(f, 1.0f) * 3.0, 0.05, 0.99);
            }
            if (st.is(Items.CROSSBOW)) {
                net.minecraft.world.item.component.ChargedProjectiles cp = st.get(DataComponents.CHARGED_PROJECTILES);
                if (cp == null || cp.isEmpty()) return null;
                return new Launch(3.15, 0.05, 0.99);
            }
            if (st.is(Items.TRIDENT)) {
                if (!p.isUsingItem() || p.getUsedItemHand() != h || p.getTicksUsingItem() < 10) return null;
                return new Launch(2.5, 0.05, 0.99);
            }
            if (st.is(Items.ENDER_PEARL) || st.is(Items.SNOWBALL) || st.is(Items.EGG)) {
                return new Launch(1.5, 0.03, 0.99);
            }
        }
        return null;
    }

    private static int[] project(Vec3 w, Vec3 eye, Vec3 fwd, Vec3 right, Vec3 up,
                                 double tanHalf, double aspect, int sw, int sh) {
        Vec3 d = w.subtract(eye);
        double zc = d.dot(fwd);
        if (zc < 0.1) return null;
        int sx = (int) (sw / 2.0 * (1 + d.dot(right) / (zc * tanHalf * aspect)));
        int sy = (int) (sh / 2.0 * (1 - d.dot(up) / (zc * tanHalf)));
        if (sx < -2000 || sx > sw + 2000 || sy < -2000 || sy > sh + 2000) return null;
        return new int[]{sx, sy};
    }

    private static void renderTrajectory(GuiGraphics g, Minecraft mc, LocalPlayer self, Font font, float pt) {
        if (mc.level == null) return;
        Launch l = launchFor(self);
        if (l == null) return;

        double yaw = Math.toRadians(self.getViewYRot(pt));
        double pitch = Math.toRadians(self.getViewXRot(pt));
        Vec3 fwd = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3 up = right.cross(fwd);
        Vec3 eye = self.getEyePosition(pt);
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        double tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        double aspect = (double) sw / sh;

        Vec3 vel = fwd.scale(l.speed());
        Vec3 mv = self.getDeltaMovement();
        vel = vel.add(mv.x, self.onGround() ? 0.0 : mv.y, mv.z);
        Vec3 pos = eye.subtract(0.0, 0.1, 0.0);
        long now = System.currentTimeMillis();
        boolean hit = false;
        int[] prev = project(pos, eye, fwd, right, up, tanHalf, aspect, sw, sh);

        for (int i = 0; i < 120; i++) {
            Vec3 next = pos.add(vel);
            net.minecraft.world.phys.BlockHitResult r = mc.level.clip(new net.minecraft.world.level.ClipContext(
                    pos, next, net.minecraft.world.level.ClipContext.Block.COLLIDER,
                    net.minecraft.world.level.ClipContext.Fluid.NONE, self));
            boolean blockHit = r.getType() != net.minecraft.world.phys.HitResult.Type.MISS;
            if (blockHit) next = r.getLocation();

            int[] cur = project(next, eye, fwd, right, up, tanHalf, aspect, sw, sh);
            if (prev != null && cur != null) {
                int dx = cur[0] - prev[0], dy = cur[1] - prev[1];
                int steps = Math.max(1, (int) Math.hypot(dx, dy));      // one pixel per step: a solid, continuous line
                int col = hudColor(now, 0);
                for (int k = 0; k <= steps; k++) {
                    int x = prev[0] + dx * k / steps, y = prev[1] + dy * k / steps;
                    g.fill(x, y, x + 1, y + 1, col);
                }
            }
            prev = cur;
            pos = next;
            if (blockHit) {
                hit = true;
                break;
            }
            vel = vel.scale(l.drag()).add(0.0, -l.gravity(), 0.0);
            if (pos.y < -256) break;
        }

        int[] end = project(pos, eye, fwd, right, up, tanHalf, aspect, sw, sh);
        if (end != null) {
            int col = hit ? 0xFFFF5555 : 0xFFFFFF55;
            g.fill(end[0] - 3, end[1] - 3, end[0] + 3, end[1] + 3, (col & 0x00FFFFFF) | 0x90000000);
            String label = (int) pos.distanceTo(eye) + "m";
            g.drawString(font, label, end[0] - font.width(label) / 2, end[1] - 14, col, true);
        }
    }

    // ---------------------------------------------------------------- extra modules

    private static boolean stepWasOn = false;
    private static boolean eatingGapple = false;
    private static int gappleRestoreSlot = -1;

    // AutoTool (used by AutoMine): switch to the hotbar item that breaks the block fastest.
    private static void selectBestTool(LocalPlayer p, BlockState state) {
        Inventory inv = p.getInventory();
        int bestSlot = inv.getSelectedSlot();
        float bestSpeed = inv.getItem(bestSlot).getDestroySpeed(state);
        for (int i = 0; i < 9; i++) {
            float sp = inv.getItem(i).getDestroySpeed(state);
            if (sp > bestSpeed) {
                bestSpeed = sp;
                bestSlot = i;
            }
        }
        if (bestSlot != inv.getSelectedSlot()) inv.setSelectedSlot(bestSlot);
    }

    private static Entity nearestTarget(Minecraft mc, LocalPlayer p, double range, boolean needSight) {
        Vec3 eye = p.getEyePosition();
        Entity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity e : mc.level.getEntities(p, p.getBoundingBox().inflate(range),
                en -> en instanceof LivingEntity le && le.isAlive() && (en instanceof Enemy || en instanceof Player))) {
            if (e.isSpectator() || e.isInvisible()) continue;
            if (needSight && !p.hasLineOfSight(e)) continue;
            double d = eyeDistance(eye, e);
            if (d > range) continue;
            Vec3 aim = aimPoint(e);
            double err = Math.abs(Mth.wrapDegrees(yawTo(eye, aim) - p.getYRot()))
                    + Math.abs(Mth.wrapDegrees(pitchTo(eye, aim) - p.getXRot()));
            double score = err + d * 4.0;
            if (score < bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    // TriggerBot: hits only when your own crosshair is already on a target (no turning).
    private static void tickTriggerBot(Minecraft mc, LocalPlayer p) {
        if (mc.level == null || !p.isAlive() || p.isSpectator()) return;
        if (p.getAttackStrengthScale(0.5f) < 1.0f) return;
        Entity t = nearestTarget(mc, p, KA_HIT_RANGE, true);
        if (t == null) return;
        Vec3 eye = p.getEyePosition();
        Vec3 aim = aimPoint(t);
        float ey = Math.abs(Mth.wrapDegrees(yawTo(eye, aim) - p.getYRot()));
        float ep = Math.abs(Mth.wrapDegrees(pitchTo(eye, aim) - p.getXRot()));
        if (ey > 8.0f || ep > 20.0f) return;
        mc.gameMode.attack(p, t);
        p.swing(InteractionHand.MAIN_HAND);
    }

    // AimAssist: gently pulls the view toward a nearby target while the attack key is held.
    private static void tickAimAssist(Minecraft mc, LocalPlayer p) {
        if (mc.level == null || !p.isAlive() || p.isSpectator() || !mc.options.keyAttack.isDown()) return;
        Entity t = nearestTarget(mc, p, KA_AIM_RANGE_ASSIST, true);
        if (t == null) return;
        Vec3 eye = p.getEyePosition();
        Vec3 aim = aimPoint(t);
        float dyaw = Mth.wrapDegrees(yawTo(eye, aim) - p.getYRot());
        float dpitch = Mth.wrapDegrees(pitchTo(eye, aim) - p.getXRot());
        if (Math.abs(dyaw) > 45.0f || Math.abs(dpitch) > 45.0f) return;   // only assist near the crosshair
        p.setYRot(p.getYRot() + Mth.clamp(dyaw * 0.25f, -6.0f, 6.0f));
        p.setXRot(Mth.clamp(p.getXRot() + Mth.clamp(dpitch * 0.25f, -4.0f, 4.0f), -90.0f, 90.0f));
    }
    private static final double KA_AIM_RANGE_ASSIST = 4.5;

    // Speed / Step / Spider / Jesus
    private static void tickMoveHacks(Minecraft mc, LocalPlayer p) {
        net.minecraft.world.entity.ai.attributes.AttributeInstance step = p.getAttribute(Attributes.STEP_HEIGHT);
        if (step != null) {
            if (STEP.enabled) {
                step.setBaseValue(1.0);
                stepWasOn = true;
            } else if (stepWasOn) {
                step.setBaseValue(0.6);
                stepWasOn = false;
            }
        }

        boolean moving = mc.options.keyUp.isDown() || mc.options.keyDown.isDown()
                || mc.options.keyLeft.isDown() || mc.options.keyRight.isDown();
        Vec3 v = p.getDeltaMovement();

        if (SPEED.enabled && moving && p.onGround()) {
            double hs = Math.hypot(v.x, v.z);
            if (hs > 0.0 && hs < 0.38) p.setDeltaMovement(v.x * 1.2, v.y, v.z * 1.2);
        }
        if (SPIDER.enabled && p.horizontalCollision && moving) {
            p.setDeltaMovement(v.x, 0.2, v.z);
        }
        if (JESUS.enabled && p.isInWater() && !mc.options.keyShift.isDown()) {
            p.setDeltaMovement(v.x, Math.max(v.y, 0.12), v.z);
        }
    }

    // AutoGapple: eats a golden apple from the hotbar when health is low.
    private static boolean isGapple(ItemStack st) {
        return st.is(Items.GOLDEN_APPLE) || st.is(Items.ENCHANTED_GOLDEN_APPLE);
    }

    private static void tickAutoGapple(Minecraft mc, LocalPlayer p) {
        if (!AUTOGAPPLE.enabled || !p.isAlive()) {
            stopEating(mc, p);
            return;
        }
        Inventory inv = p.getInventory();
        if (!eatingGapple && p.getHealth() <= 10.0f && mc.gui.screen() == null) {
            for (int i = 0; i < 9; i++) {
                if (isGapple(inv.getItem(i))) {
                    gappleRestoreSlot = inv.getSelectedSlot();
                    inv.setSelectedSlot(i);
                    mc.options.keyUse.setDown(true);
                    eatingGapple = true;
                    return;
                }
            }
        } else if (eatingGapple && (p.getHealth() > 14.0f || !isGapple(p.getMainHandItem()))) {
            stopEating(mc, p);
        }
    }

    // ---------------------------------------------------------------- PvE: AutoEat / AutoTool

    private static boolean eatingFood = false;
    private static int foodRestoreSlot = -1;

    private static boolean isFood(ItemStack st) {
        if (st.isEmpty() || !st.has(DataComponents.FOOD) || isGapple(st)) return false;
        return !(st.is(Items.ROTTEN_FLESH) || st.is(Items.SPIDER_EYE) || st.is(Items.POISONOUS_POTATO)
                || st.is(Items.PUFFERFISH) || st.is(Items.CHICKEN) || st.is(Items.CHORUS_FRUIT));
    }

    // AutoEat: eats safe food from the hotbar when hunger drops, then returns to the previous slot.
    private static void tickAutoEat(Minecraft mc, LocalPlayer p) {
        if (!AUTOEAT.enabled || !p.isAlive() || eatingGapple) {
            stopEatingFood(mc, p);
            return;
        }
        int food = p.getFoodData().getFoodLevel();
        Inventory inv = p.getInventory();
        if (!eatingFood && food <= 14 && mc.gui.screen() == null) {
            for (int i = 0; i < 9; i++) {
                if (isFood(inv.getItem(i))) {
                    foodRestoreSlot = inv.getSelectedSlot();
                    inv.setSelectedSlot(i);
                    mc.options.keyUse.setDown(true);
                    eatingFood = true;
                    return;
                }
            }
        } else if (eatingFood && (food >= 18 || !isFood(p.getMainHandItem()))) {
            stopEatingFood(mc, p);
        }
    }

    private static void stopEatingFood(Minecraft mc, LocalPlayer p) {
        if (!eatingFood) return;
        mc.options.keyUse.setDown(false);
        if (foodRestoreSlot >= 0) p.getInventory().setSelectedSlot(foodRestoreSlot);
        foodRestoreSlot = -1;
        eatingFood = false;
    }

    // AutoTool: while you hold attack on a block, switch to the hotbar item that breaks it fastest.
    private static void tickAutoTool(Minecraft mc, LocalPlayer p) {
        if (!AUTOTOOL.enabled || AUTOMINE.enabled || mc.level == null || mc.gui.screen() != null) return;
        if (!mc.options.keyAttack.isDown()) return;
        if (mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult bhr
                && bhr.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK) {
            selectBestTool(p, mc.level.getBlockState(bhr.getBlockPos()));
        }
    }

    // AutoFish: casts the rod, reels in when the bobber is pulled under, then casts again.
    private static boolean fishPressed = false;
    private static int fishCooldown = 0;
    private static double fishLastY = Double.NaN;

    // ---------------------------------------------------------------- AutoPlant
    // Plants seeds / carrots / potatoes from the hotbar on every empty farmland block within reach.
    private static int plantCd = 0;

    private static boolean isSeed(ItemStack st) {
        return st.is(Items.WHEAT_SEEDS) || st.is(Items.BEETROOT_SEEDS) || st.is(Items.CARROT) || st.is(Items.POTATO);
    }

    private static void tickAutoPlant(Minecraft mc, LocalPlayer p) {
        if (!AUTOPLANT.enabled || mc.level == null || mc.gameMode == null || mc.gui.screen() != null
                || !p.isAlive() || p.isSpectator()) return;
        if (plantCd > 0) {
            plantCd--;
            return;
        }
        Inventory inv = p.getInventory();
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack st = inv.getItem(i);
            if (!st.isEmpty() && isSeed(st)) {
                slot = i;
                break;
            }
        }
        if (slot < 0) return;                                   // no seeds in the hotbar

        Vec3 eye = p.getEyePosition();
        BlockPos c = p.blockPosition();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        int r = 4;
        for (BlockPos pos : BlockPos.betweenClosed(c.offset(-r, -2, -r), c.offset(r, 1, r))) {
            if (!mc.level.getBlockState(pos).is(net.minecraft.world.level.block.Blocks.FARMLAND)) continue;
            if (!mc.level.getBlockState(pos.above()).isAir()) continue;
            double d = eye.distanceTo(new Vec3(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5));
            if (d > 4.0 || d >= bestD) continue;
            bestD = d;
            best = pos.immutable();
        }
        if (best == null) return;

        if (inv.getSelectedSlot() != slot) inv.setSelectedSlot(slot);
        Vec3 hit = new Vec3(best.getX() + 0.5, best.getY() + 1.0, best.getZ() + 0.5);
        mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND,
                new net.minecraft.world.phys.BlockHitResult(hit, Direction.UP, best, false));
        p.swing(InteractionHand.MAIN_HAND);
        plantCd = 2;
    }

    // ---------------------------------------------------------------- AutoHarvest
    // Breaks grown crops, sugar cane, cactus, bamboo, melons and pumpkins within reach.
    // Cane, cactus and bamboo keep their bottom block, so they grow back.
    private static int harvestCd = 0;
    private static BlockPos harvestPos = null;
    private static int farmClock = 0;                       // ticks since start, shared by the farm modules

    private static boolean harvestable(Minecraft mc, BlockPos pos) {
        BlockState st = mc.level.getBlockState(pos);
        net.minecraft.world.level.block.Block b = st.getBlock();
        if (b instanceof net.minecraft.world.level.block.CropBlock crop) return crop.isMaxAge(st);
        if (b == Blocks.SUGAR_CANE || b == Blocks.CACTUS || b == Blocks.BAMBOO) {
            return mc.level.getBlockState(pos.below()).getBlock() == b;      // leave the bottom block
        }
        return b == Blocks.MELON || b == Blocks.PUMPKIN;
    }

    private static void tickAutoHarvest(Minecraft mc, LocalPlayer p) {
        if (!AUTOHARVEST.enabled || mc.level == null || mc.gameMode == null || mc.gui.screen() != null
                || !p.isAlive() || p.isSpectator()) {
            harvestPos = null;
            return;
        }
        Vec3 eye = p.getEyePosition();
        // keep breaking the current block until it is gone or out of reach
        if (harvestPos != null && (!harvestable(mc, harvestPos)
                || eye.distanceTo(Vec3.atCenterOf(harvestPos)) > 4.0)) {
            harvestPos = null;
        }
        if (harvestPos == null) {
            if (harvestCd > 0) {
                harvestCd--;
                return;
            }
            BlockPos c = p.blockPosition();
            BlockPos best = null;
            double bestD = Double.MAX_VALUE;
            int r = 4;
            for (BlockPos pos : BlockPos.betweenClosed(c.offset(-r, -2, -r), c.offset(r, 3, r))) {
                if (!harvestable(mc, pos)) continue;
                double d = eye.distanceTo(Vec3.atCenterOf(pos));
                if (d > 4.0 || d >= bestD) continue;
                bestD = d;
                best = pos.immutable();
            }
            if (best == null) return;
            harvestPos = best;
            mc.gameMode.startDestroyBlock(harvestPos, Direction.UP);
            p.swing(InteractionHand.MAIN_HAND);
            harvestCd = 1;
            return;
        }
        mc.gameMode.continueDestroyBlock(harvestPos, Direction.UP);
        p.swing(InteractionHand.MAIN_HAND);
    }

    // ---------------------------------------------------------------- farm helpers
    private static int emptySlots(Inventory inv) {
        int n = 0;
        for (int i = 0; i < 36; i++) if (inv.getItem(i).isEmpty()) n++;
        return n;
    }

    private static boolean hasSeeds(Inventory inv) {
        for (int i = 0; i < 9; i++) {
            ItemStack st = inv.getItem(i);
            if (!st.isEmpty() && isSeed(st)) return true;
        }
        return false;
    }

    private static boolean isProduce(ItemStack st) {
        return st.is(Items.WHEAT) || st.is(Items.WHEAT_SEEDS) || st.is(Items.BEETROOT_SEEDS) || st.is(Items.BEETROOT)
                || st.is(Items.CARROT) || st.is(Items.POTATO) || st.is(Items.POISONOUS_POTATO)
                || st.is(Items.SUGAR_CANE) || st.is(Items.CACTUS) || st.is(Items.BAMBOO)
                || st.is(Items.MELON_SLICE) || st.is(Items.PUMPKIN)
                || st.is(Items.MELON_SEEDS) || st.is(Items.PUMPKIN_SEEDS);
    }

    private static boolean farmWanted(Minecraft mc, BlockPos pos, boolean seeds) {
        if (AUTOHARVEST.enabled && harvestable(mc, pos)) return true;
        return AUTOPLANT.enabled && seeds
                && mc.level.getBlockState(pos).is(Blocks.FARMLAND)
                && mc.level.getBlockState(pos.above()).isAir();
    }

    private static Entity findDrop(Minecraft mc, LocalPlayer p, double range) {
        Entity best = null;
        double bd = Double.MAX_VALUE;
        for (Entity e : mc.level.getEntities(p, p.getBoundingBox().inflate(range, 4.0, range),
                en -> en instanceof net.minecraft.world.entity.item.ItemEntity)) {
            if (farmIgnore.contains(e.getId())) continue;
            if (!isProduce(((net.minecraft.world.entity.item.ItemEntity) e).getItem())) continue;
            double d = p.distanceToSqr(e);
            if (d < bd) {
                bd = d;
                best = e;
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- AutoStash
    // When the inventory fills up with farm products, puts them into the nearest chest / barrel.
    // Seeds in the hotbar stay (they are needed for planting). AutoFarm walks to the chest.
    private static boolean stashBusy = false;
    private static int stashCd = 0, stashTicks = 0;
    private static BlockPos stashChest = null;
    private static final List<BlockPos> stashChests = new ArrayList<>();
    private static final java.util.Map<BlockPos, Integer> stashFull = new java.util.HashMap<>();

    private static boolean stashKeep(int invIndex, ItemStack st) {
        return invIndex < 9 && isSeed(st);
    }

    private static boolean stashNeeded(Inventory inv) {
        int n = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack st = inv.getItem(i);
            if (!st.isEmpty() && isProduce(st) && !stashKeep(i, st)) n++;
        }
        return n >= 5 || (n >= 1 && emptySlots(inv) <= 2);
    }

    private static void scanStashChests(Minecraft mc, LocalPlayer p) {
        stashChests.clear();
        BlockPos c = p.blockPosition();
        int r = 16;
        for (BlockPos pos : BlockPos.betweenClosed(c.offset(-r, -4, -r), c.offset(r, 4, r))) {
            net.minecraft.world.level.block.Block b = mc.level.getBlockState(pos).getBlock();
            if (b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.BARREL) stashChests.add(pos.immutable());
        }
    }

    private static BlockPos nearestChest(Minecraft mc, LocalPlayer p) {
        Vec3 eye = p.getEyePosition();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (BlockPos pos : stashChests) {
            Integer until = stashFull.get(pos);
            if (until != null && until > farmClock) continue;          // full recently
            double d = eye.distanceToSqr(Vec3.atCenterOf(pos));
            if (d < bd) {
                bd = d;
                best = pos;
            }
        }
        return best;
    }

    private static void tickAutoStash(Minecraft mc, LocalPlayer p) {
        farmClock++;
        if (stashCd > 0) stashCd--;
        boolean inChest = mc.gui.screen() instanceof net.minecraft.client.gui.screens.inventory.AbstractContainerScreen<?>;
        if (!AUTOSTASH.enabled || mc.level == null || mc.gameMode == null || !p.isAlive() || p.isSpectator()) {
            if (stashBusy && inChest) p.closeContainer();
            stashBusy = false;
            return;
        }
        if (stashBusy) {
            if (!inChest) {                                            // waiting for the chest to open
                if (++stashTicks > 20) {
                    stashBusy = false;
                    stashCd = 60;
                    if (stashChest != null) stashFull.put(stashChest, farmClock + 600);
                }
                return;
            }
            stashMove(mc, p);
            return;
        }
        if (mc.gui.screen() != null || stashCd > 0) return;
        if (farmClock % 40 == 0) scanStashChests(mc, p);
        if (!stashNeeded(p.getInventory())) return;
        BlockPos ch = nearestChest(mc, p);
        if (ch == null) return;
        Vec3 eye = p.getEyePosition();
        Vec3 tc = Vec3.atCenterOf(ch);
        if (eye.distanceTo(tc) > 4.0) return;                          // AutoFarm walks closer
        Direction face = Direction.getApproximateNearest(eye.x - tc.x, eye.y - tc.y, eye.z - tc.z);
        mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND,
                new net.minecraft.world.phys.BlockHitResult(tc, face, ch, false));
        p.swing(InteractionHand.MAIN_HAND);
        stashChest = ch;
        stashBusy = true;
        stashTicks = 0;
    }

    private static void stashMove(Minecraft mc, LocalPlayer p) {
        net.minecraft.world.inventory.AbstractContainerMenu menu = p.containerMenu;
        int chestSlots = menu.slots.size() - 36;                       // the rest is the player inventory
        Inventory inv = p.getInventory();
        int moved = 0;
        boolean left = false;
        if (chestSlots > 0) {
            for (int i = 0; i < 36; i++) {
                ItemStack st = inv.getItem(i);
                if (st.isEmpty() || !isProduce(st) || stashKeep(i, st)) continue;
                left = true;
                if (moved < 4) {
                    int slot = chestSlots + (i >= 9 ? i - 9 : 27 + i);  // main inventory first, then hotbar
                    mc.gameMode.handleInventoryMouseClick(menu.containerId, slot, 0, ClickType.QUICK_MOVE, p);
                    moved++;
                }
            }
        }
        stashTicks++;
        if (!left || stashTicks > 40) {
            if (left && stashChest != null) stashFull.put(stashChest, farmClock + 3000);   // chest is full
            p.closeContainer();
            stashBusy = false;
            stashCd = 40;
        }
    }

    // ---------------------------------------------------------------- AutoBreed
    // Feeds pairs of cows, sheep, pigs and chickens with the right food from the hotbar.
    // Each animal is fed once per 5 minutes, and a species is left alone once 14+ are nearby.
    private static int breedCd = 0;
    private static final java.util.Map<Integer, Integer> bredAt = new java.util.HashMap<>();

    // Animal kind by registry id ("minecraft:cow"), so no EntityType constants are needed.
    private static String typeId(Entity e) {
        return net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).toString();
    }

    private static boolean breedable(Entity e) {
        String t = typeId(e);
        return t.equals("minecraft:cow") || t.equals("minecraft:sheep") || t.equals("minecraft:pig")
                || t.equals("minecraft:chicken") || t.equals("minecraft:mooshroom");
    }

    private static boolean isBreedFood(Entity e, ItemStack st) {
        String t = typeId(e);
        if (t.equals("minecraft:pig")) {
            return st.is(Items.CARROT) || st.is(Items.POTATO) || st.is(Items.BEETROOT);
        }
        if (t.equals("minecraft:chicken")) {
            return st.is(Items.WHEAT_SEEDS) || st.is(Items.BEETROOT_SEEDS)
                    || st.is(Items.MELON_SEEDS) || st.is(Items.PUMPKIN_SEEDS);
        }
        return st.is(Items.WHEAT);                                     // cow, sheep, mooshroom
    }

    private static int foodSlot(Inventory inv, Entity e) {
        for (int i = 0; i < 9; i++) {
            ItemStack st = inv.getItem(i);
            if (!st.isEmpty() && isBreedFood(e, st)) return i;
        }
        return -1;
    }

    private static boolean breedCandidate(Entity e) {
        if (!breedable(e) || !e.isAlive() || !(e instanceof LivingEntity le) || le.isBaby()) return false;
        Integer at = bredAt.get(e.getId());
        return at == null || farmClock - at > 6000;
    }

    // Nearest animal worth feeding right now (needs food in hand and a partner), or null.
    private static Entity breedTarget(Minecraft mc, LocalPlayer p, double range) {
        Inventory inv = p.getInventory();
        List<Entity> list = mc.level.getEntities(p, p.getBoundingBox().inflate(range, 4.0, range),
                en -> breedable(en) && en.isAlive());
        java.util.Map<Object, int[]> stats = new java.util.HashMap<>();   // type -> {total, candidates, fed recently}
        for (Entity e : list) {
            int[] s = stats.computeIfAbsent(e.getType(), k -> new int[3]);
            s[0]++;
            if (breedCandidate(e)) s[1]++;
            Integer at = bredAt.get(e.getId());
            if (at != null && farmClock - at < 200) s[2]++;
        }
        Entity best = null;
        double bd = Double.MAX_VALUE;
        for (Entity e : list) {
            if (!breedCandidate(e) || farmIgnore.contains(e.getId()) || foodSlot(inv, e) < 0) continue;
            int[] s = stats.get(e.getType());
            if (s[0] >= 14) continue;                                  // enough animals already
            if (s[1] < 2 && !(s[1] >= 1 && s[2] >= 1)) continue;       // no partner
            double d = p.distanceToSqr(e);
            if (d < bd) {
                bd = d;
                best = e;
            }
        }
        return best;
    }

    private static void tickAutoBreed(Minecraft mc, LocalPlayer p) {
        if (breedCd > 0) breedCd--;
        if (!AUTOBREED.enabled || breedCd > 0 || mc.level == null || mc.gameMode == null
                || mc.gui.screen() != null || !p.isAlive() || p.isSpectator()) return;
        Entity a = breedTarget(mc, p, 4.0);
        if (a == null) return;
        if (p.getEyePosition().distanceTo(a.getBoundingBox().getCenter()) > 2.9) return;   // AutoFarm walks closer
        Inventory inv = p.getInventory();
        int slot = foodSlot(inv, a);
        if (slot < 0) return;
        if (inv.getSelectedSlot() != slot) inv.setSelectedSlot(slot);
        mc.gameMode.interact(p, a, new net.minecraft.world.phys.EntityHitResult(a), InteractionHand.MAIN_HAND);
        p.swing(InteractionHand.MAIN_HAND);
        bredAt.put(a.getId(), farmClock);
        breedCd = 8;
    }

    // ---------------------------------------------------------------- AutoFarm (walking)
    // Legs for the farm modules. Walks, in this order, to: a chest (when AutoStash needs one), the nearest
    // job for AutoPlant / AutoHarvest, dropped farm items, animals for AutoBreed. The other modules do the work.
    private static boolean farmWalking = false, farmJump = false;
    private static BlockPos farmTarget = null;
    private static Object farmKey = null;
    private static int farmWalkTicks = 0;
    private static final java.util.Set<Object> farmIgnore = new java.util.HashSet<>();

    private static void releaseFarm(Minecraft mc) {
        if (farmWalking) {
            mc.options.keyUp.setDown(false);
            farmWalking = false;
        }
        if (farmJump) {
            mc.options.keyJump.setDown(false);
            farmJump = false;
        }
        farmTarget = null;
        farmKey = null;
        farmWalkTicks = 0;
    }

    private static void tickAutoFarm(Minecraft mc, LocalPlayer p) {
        if (farmJump) {                                   // release the jump pressed last tick
            mc.options.keyJump.setDown(false);
            farmJump = false;
        }
        if (!AUTOFARM.enabled || mc.level == null || !p.isAlive() || p.isSpectator()
                || mc.gui.screen() != null || stashBusy) {
            releaseFarm(mc);
            return;
        }
        if (p.getHealth() <= 6.0f) {                      // safety stop
            AUTOFARM.enabled = false;
            releaseFarm(mc);
            p.sendSystemMessage(Component.literal("[VoidDls] AutoFarm stopped: low health"));
            return;
        }
        if (farmClock % 600 == 0) farmIgnore.clear();

        Inventory inv = p.getInventory();
        Vec3 eye = p.getEyePosition();
        Vec3 goal = null;
        double reach = 3.3;
        boolean flat = false;                             // measure along the ground only (dropped items)
        Object key = null;

        // 1. a chest, when the inventory is getting full
        if (AUTOSTASH.enabled && stashNeeded(inv)) {
            BlockPos ch = nearestChest(mc, p);
            if (ch != null && !farmIgnore.contains(ch)) {
                goal = Vec3.atCenterOf(ch);
                reach = 3.2;
                key = ch;
            }
        }
        // 2. planting / harvesting work
        if (goal == null && (AUTOPLANT.enabled || AUTOHARVEST.enabled)) {
            boolean seeds = hasSeeds(inv);
            if (farmTarget != null && !farmWanted(mc, farmTarget, seeds)) farmTarget = null;
            if (farmTarget == null || farmClock % 20 == 0) {
                BlockPos c = p.blockPosition();
                BlockPos best = null;
                double bestD = Double.MAX_VALUE;
                int r = 16;
                for (BlockPos pos : BlockPos.betweenClosed(c.offset(-r, -2, -r), c.offset(r, 3, r))) {
                    if (farmIgnore.contains(pos) || !farmWanted(mc, pos, seeds)) continue;
                    double d = eye.distanceToSqr(Vec3.atCenterOf(pos));
                    if (d < bestD) {
                        bestD = d;
                        best = pos.immutable();
                    }
                }
                farmTarget = best;
            }
            if (farmTarget != null) {
                boolean land = mc.level.getBlockState(farmTarget).is(Blocks.FARMLAND);
                goal = new Vec3(farmTarget.getX() + 0.5, farmTarget.getY() + (land ? 1.0 : 0.5), farmTarget.getZ() + 0.5);
                key = farmTarget;
            }
        }
        // 3. dropped farm items
        if (goal == null && emptySlots(inv) > 0) {
            Entity it = findDrop(mc, p, 16.0);
            if (it != null) {
                goal = it.position();
                reach = 1.0;
                flat = true;
                key = it.getId();
            }
        }
        // 4. animals to breed
        if (goal == null && AUTOBREED.enabled) {
            Entity a = breedTarget(mc, p, 16.0);
            if (a != null) {
                goal = a.getBoundingBox().getCenter();
                reach = 2.5;
                key = a.getId();
            }
        }
        if (goal == null) {                               // nothing left to do
            releaseFarm(mc);
            return;
        }
        if (!java.util.Objects.equals(key, farmKey)) {
            farmKey = key;
            farmWalkTicks = 0;
        }

        double dist = flat ? Math.hypot(goal.x - p.getX(), goal.z - p.getZ()) : eye.distanceTo(goal);
        if (dist <= reach) {                              // close enough: stand still, the other modules work
            if (farmWalking) {
                mc.options.keyUp.setDown(false);
                farmWalking = false;
            }
            farmWalkTicks = 0;
            return;
        }

        float dyaw = Mth.wrapDegrees(yawTo(eye, goal) - p.getYRot());
        p.setYRot(p.getYRot() + Mth.clamp(dyaw * 0.6f, -KA_MAX_TURN, KA_MAX_TURN));
        mc.options.keyUp.setDown(true);
        farmWalking = true;
        if (p.horizontalCollision && p.onGround()) {
            mc.options.keyJump.setDown(true);
            farmJump = true;
        }
        if (++farmWalkTicks > 160) {                      // cannot get there: skip it for a while
            farmIgnore.add(key);
            farmTarget = null;
            farmKey = null;
            farmWalkTicks = 0;
        }
    }

    private static void tickAutoFish(Minecraft mc, LocalPlayer p) {
        if (fishPressed) {                                 // release the use key pressed last tick
            if (!eatingFood && !eatingGapple) mc.options.keyUse.setDown(false);
            fishPressed = false;
        }
        if (!AUTOFISH.enabled || !p.isAlive() || mc.gui.screen() != null || eatingFood || eatingGapple
                || !p.getMainHandItem().is(Items.FISHING_ROD)) {
            fishLastY = Double.NaN;
            return;
        }
        if (fishCooldown > 0) {
            fishCooldown--;
            return;
        }
        Entity hook = p.fishing;
        if (hook == null) {                                // no bobber out: cast
            mc.options.keyUse.setDown(true);
            fishPressed = true;
            fishCooldown = 25;
            fishLastY = Double.NaN;
            return;
        }
        double y = hook.getY();
        if (hook.tickCount < 30) {                         // ignore the splash right after casting
            fishLastY = y;
            return;
        }
        boolean bite = !Double.isNaN(fishLastY) && fishLastY - y > 0.12 && hook.isInWater();
        fishLastY = y;
        if (bite) {                                        // bobber dipped: reel in
            mc.options.keyUse.setDown(true);
            fishPressed = true;
            fishCooldown = 20;
            fishLastY = Double.NaN;
        }
    }

    private static void stopEating(Minecraft mc, LocalPlayer p) {
        if (!eatingGapple) return;
        mc.options.keyUse.setDown(false);
        if (gappleRestoreSlot >= 0) p.getInventory().setSelectedSlot(gappleRestoreSlot);
        gappleRestoreSlot = -1;
        eatingGapple = false;
    }

    private static Vec3 aimPoint(Entity e) {
        return new Vec3(e.getX(), e.getY() + e.getBbHeight() * 0.75, e.getZ());   // upper body
    }

    // distance from the eyes to the closest point of the target's hitbox
    private static double eyeDistance(Vec3 eye, Entity e) {
        net.minecraft.world.phys.AABB bb = e.getBoundingBox();
        double cx = Mth.clamp(eye.x, bb.minX, bb.maxX);
        double cy = Mth.clamp(eye.y, bb.minY, bb.maxY);
        double cz = Mth.clamp(eye.z, bb.minZ, bb.maxZ);
        return eye.distanceTo(new Vec3(cx, cy, cz));
    }

    private static float yawTo(Vec3 from, Vec3 to) {
        return (float) (Math.toDegrees(Math.atan2(to.z - from.z, to.x - from.x)) - 90.0);
    }

    private static float pitchTo(Vec3 from, Vec3 to) {
        double horiz = Math.hypot(to.x - from.x, to.z - from.z);
        return (float) -Math.toDegrees(Math.atan2(to.y - from.y, horiz));
    }

    private static void tickZoom(Minecraft mc) {
        if (kZoom.isDown() && mc.gui.screen() == null) {
            if (savedFov == null) savedFov = mc.options.fov().get();
            mc.options.fov().set(30);
        } else if (savedFov != null) {
            mc.options.fov().set(savedFov);
            savedFov = null;
        }
    }

    private static void tickDeath(Minecraft mc, LocalPlayer p) {
        if (mc.gui.screen() instanceof DeathScreen) {
            if (!deathAnnounced) {
                deathAnnounced = true;
                p.sendSystemMessage(Component.literal(String.format(
                        "[VoidDls] Death: %d %d %d",
                        (int) Math.floor(p.getX()), (int) Math.floor(p.getY()), (int) Math.floor(p.getZ()))));
            }
            if (AUTORESPAWN.enabled) p.respawn();
        } else {
            deathAnnounced = false;
        }
    }

    private static void tickFullbright(LocalPlayer p) {
        if (FULLBRIGHT.enabled) {
            MobEffectInstance cur = p.getEffect(MobEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 300) {
                p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1000, 0, false, false, false));
                nightVisionAdded = true;
            }
        } else if (nightVisionAdded) {
            nightVisionAdded = false;
            p.removeEffectNoUpdate(MobEffects.NIGHT_VISION);
        }
    }

    private static void tickFly(LocalPlayer p) {
        Abilities ab = p.getAbilities();
        if (FLY.enabled) {
            ab.mayfly = true;           // then double-tap Space like in creative
            flyWasOn = true;
        } else if (flyWasOn) {
            flyWasOn = false;
            if (!p.isCreative() && !p.isSpectator()) {
                ab.mayfly = false;
                ab.flying = false;
            }
        }
    }

    private static void tickMovement(Minecraft mc) {
        if (AUTOSPRINT.enabled) {
            mc.options.keySprint.setDown(true);
            sprintWasOn = true;
        } else if (sprintWasOn) {
            sprintWasOn = false;
            mc.options.keySprint.setDown(false);
        }

        if (AUTOWALK.enabled && mc.gui.screen() == null) {
            mc.options.keyUp.setDown(true);
            walkWasOn = true;
        } else if (walkWasOn) {
            walkWasOn = false;
            mc.options.keyUp.setDown(false);
        }
    }

    // ================================================================ inventory

    private static void swapTotemShield(Minecraft mc, LocalPlayer p) {
        Item wanted;
        if (p.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
            wanted = Items.SHIELD;
        } else if (p.getOffhandItem().is(Items.SHIELD)) {
            wanted = Items.TOTEM_OF_UNDYING;
        } else {
            wanted = findIndex(p.getInventory(), Items.TOTEM_OF_UNDYING) != -1
                    ? Items.TOTEM_OF_UNDYING : Items.SHIELD;
        }
        swapOffhandWith(mc, p, wanted);
    }

    private static void swapOffhandWith(Minecraft mc, LocalPlayer p, Item wanted) {
        int index = findIndex(p.getInventory(), wanted);
        if (index == -1) return;
        int slotId = index < 9 ? index + 36 : index;   // inventory index -> menu slot id
        // SWAP with button 40 swaps the clicked slot with the offhand.
        mc.gameMode.handleInventoryMouseClick(
                p.inventoryMenu.containerId, slotId, 40, ClickType.SWAP, p);
    }

    private static int findIndex(Inventory inv, Item item) {
        for (int i = 0; i < 36; i++) {
            if (inv.getItem(i).is(item)) return i;
        }
        return -1;
    }

    // ================================================================ HUD

    private static void renderHud(GuiGraphics graphics, DeltaTracker tick) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;

        Font font = mc.font;
        int lh = font.lineHeight + 3;
        long now = System.currentTimeMillis();

        if (tintMode != 0) {                                         // color filter over the world
            int alpha = TINT_STRENGTH[tintStrength] * 255 / 100;
            graphics.fill(0, 0, mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight(),
                    (alpha << 24) | TINT_RGB[tintMode]);
        }

        // top-left: small client watermark with animated gradient
        String mark = "VoidDls";
        int mw = font.width(mark);
        int wh = font.lineHeight + 2;
        graphics.fill(2, 2, mw + 8, 2 + wh, 0x90000000);
        graphics.fill(2, 2, 3, 2 + wh, hudColor(now, 0));
        for (int i = 0, x = 5; i < mark.length(); i++) {
            String ch = String.valueOf(mark.charAt(i));
            graphics.drawString(font, ch, x, 4, hudColor(now, i * 120), true);
            x += font.width(ch);
        }

        // bottom-left: coordinates + FPS (coordinates only when toggled on)
        int sh = mc.getWindow().getGuiScaledHeight();
        int by = sh - lh - 2;
        String fps = mc.getFps() + " FPS";
        graphics.fill(2, by - 1, font.width(fps) + 10, by + lh - 2, 0x90000000);
        graphics.drawString(font, fps, 6, by + 1, 0xFFFFFFFF, true);
        if (COORDS.enabled) {
            by -= lh;
            String line = String.format("XYZ %d %d %d  %s",
                    (int) Math.floor(p.getX()), (int) Math.floor(p.getY()), (int) Math.floor(p.getZ()),
                    p.getDirection().getName());
            graphics.fill(2, by - 1, font.width(line) + 10, by + lh - 2, 0x90000000);
            graphics.drawString(font, line, 6, by + 1, 0xFFFFFFFF, true);
        }

        if (TRAJECTORY.enabled) {
            renderTrajectory(graphics, mc, p, font, tick.getGameTimeDeltaPartialTick(false));
        }
        if (TARGETESP.enabled || TRAILS.enabled || JUMPCIRCLES.enabled || BLOCKOVERLAY.enabled) {
            renderShapes(graphics, mc, p, now, tick.getGameTimeDeltaPartialTick(false));
        }
        if (DMGNUM.enabled || HITFX.enabled) {
            renderWorldFx(graphics, mc, p, font, tick.getGameTimeDeltaPartialTick(false));
        }
        if (TARGETHUD.enabled) renderTargetHud(graphics, mc, p, font, now);
        if (COOLDOWNS.enabled) renderCooldowns(graphics, mc, p, tick.getGameTimeDeltaPartialTick(false), now);
        if (ORE_ESP.enabled) {
            renderOreEsp(graphics, mc, p, font, tick.getGameTimeDeltaPartialTick(false));
        }

        if (GEARVIEW.enabled || ESP_PLAYERS.enabled) {
            renderGearView(graphics, mc, p, font, tick.getGameTimeDeltaPartialTick(false));
        }
    }



    // ---------------------------------------------------------------- world visuals: weather, tint, particles
    public static final String[] WEATHER_NAMES = {"Off", "Clear", "Rain", "Storm"};
    public static final String[] TINT_NAMES = {"Off", "Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Purple", "Pink"};
    public static final int[] TINT_RGB = {0, 0xFF2020, 0xFF8020, 0xFFE020, 0x20FF40, 0x20E0FF, 0x2060FF, 0xA040FF, 0xFF60C0};
    public static final int[] TINT_STRENGTH = {10, 20, 30, 45};
    public static final String[] PFX_NAMES = {"Flame", "End Rod", "Hearts", "Crit", "Enchant", "Soul", "Snow", "Spark", "Note", "Cloud", "Ash"};
    public static final String[] PMODE_NAMES = {"Aura", "Trail", "Ring"};
    public static int weatherMode = 0;
    public static int tintMode = 0;
    public static int tintStrength = 1;
    public static int particleType = 0;
    public static int particleMode = 0;
    public static boolean hitWorldFx = false;

    private static double rnd(double r) {
        return (KA_RNG.nextDouble() - 0.5) * 2.0 * r;
    }

    private static net.minecraft.core.particles.ParticleOptions pfx(int i) {
        switch (i) {
            case 1: return net.minecraft.core.particles.ParticleTypes.END_ROD;
            case 2: return net.minecraft.core.particles.ParticleTypes.HEART;
            case 3: return net.minecraft.core.particles.ParticleTypes.CRIT;
            case 4: return net.minecraft.core.particles.ParticleTypes.ENCHANT;
            case 5: return net.minecraft.core.particles.ParticleTypes.SOUL_FIRE_FLAME;
            case 6: return net.minecraft.core.particles.ParticleTypes.SNOWFLAKE;
            case 7: return net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK;
            case 8: return net.minecraft.core.particles.ParticleTypes.NOTE;
            case 9: return net.minecraft.core.particles.ParticleTypes.CLOUD;
            case 10: return net.minecraft.core.particles.ParticleTypes.ASH;
            default: return net.minecraft.core.particles.ParticleTypes.FLAME;
        }
    }

    private static void tickParticleFx(Minecraft mc, LocalPlayer p) {
        net.minecraft.core.particles.ParticleOptions opt = pfx(particleType);
        double px = p.getX(), py = p.getY(), pz = p.getZ();
        if (particleMode == 1) {                                     // trail: only while moving
            if (p.getDeltaMovement().horizontalDistanceSqr() > 0.0004) {
                for (int i = 0; i < 2; i++) mc.level.addParticle(opt, px + rnd(0.3), py + 0.1, pz + rnd(0.3), 0.0, 0.02, 0.0);
            }
        } else if (particleMode == 2) {                              // ring orbiting the waist
            for (int i = 0; i < 3; i++) {
                double a = p.tickCount * 0.35 + i * Math.PI * 2.0 / 3.0;
                mc.level.addParticle(opt, px + Math.cos(a) * 0.8, py + 0.9, pz + Math.sin(a) * 0.8, 0.0, 0.0, 0.0);
            }
        } else {                                                     // aura around the body
            for (int i = 0; i < 2; i++) {
                mc.level.addParticle(opt, px + rnd(0.7), py + KA_RNG.nextDouble() * 1.8, pz + rnd(0.7), 0.0, 0.02, 0.0);
            }
        }
    }


    // ---------------------------------------------------------------- shapes: Target ESP, Trails, Jump Circles, Block Overlay
    public static final String[] COLOR_NAMES = {"Purple", "Violet", "Indigo", "Blue", "Sky", "Cyan", "Teal", "Mint", "Green", "Lime", "Yellow", "Gold", "Orange", "Coral", "Red", "Crimson", "Pink", "Magenta", "Brown", "Gray", "White", "Black", "Rainbow", "Aurora", "Fire", "Ocean", "Candy"};
    public static final int[] COLOR_RGB = {0xA040FF, 0x7A5CFF, 0x4B3FD6, 0x2060FF, 0x5EB8FF, 0x20E0FF, 0x14B8A6, 0x7CFFCB, 0x20FF40, 0xB6FF2A, 0xFFE020, 0xFFC21A, 0xFF8020, 0xFF6F61, 0xFF2020, 0xC21E3A, 0xFF60C0, 0xFF2AD4, 0x8B5A2B, 0x9AA0A6, 0xFFFFFF, 0x101010, -1, -2, -3, -4, -5};   // negative = animated palette
    private static final int[][] ANIM_PAL = {{0x20FF90, 0x2090FF}, {0xFF2A00, 0xFFC800}, {0x2060FF, 0x20E0FF}, {0xFF60C0, 0xA040FF}};
    private static int ci(String name) {
        for (int i = 0; i < COLOR_NAMES.length; i++) if (COLOR_NAMES[i].equals(name)) return i;
        return 0;
    }
    public static final String[] SIZE_NAMES = {"Small", "Medium", "Large"};
    public static final String[] SPEED_NAMES = {"Slow", "Normal", "Fast"};
    public static final String[] LINE_NAMES = {"1px", "2px", "3px"};
    public static final String[] TE_STYLE_NAMES = {"Ring", "Rising", "Twin", "Orbs"};
    public static final String[] TR_LEN_NAMES = {"Short", "Medium", "Long", "Max"};
    public static final String[] TR_WHO_NAMES = {"Self", "Players"};
    public static final String[] BO_MODE_NAMES = {"Outline", "Fill", "Both"};
    public static final String[] OFFON_NAMES = {"Off", "On"};
    public static final String[] DENSITY_NAMES = {"Low", "Normal", "High", "Max"};
    public static final String[] RANGE_NAMES = {"Near", "Medium", "Far"};
    public static final String[] COUNT_NAMES = {"Few", "Normal", "Many"};
    private static final double[] TE_SIZE = {0.7, 1.0, 1.4};
    private static final double[] TE_SPEED = {0.5, 1.0, 2.0};
    private static final int[] LINE_PX = {1, 2, 3};
    private static final int[] TR_LEN = {20, 40, 80, 140};
    private static final double[] JC_RADIUS = {1.5, 2.5, 3.5};
    private static final int[] JC_LIFE = {30, 20, 12};
    private static final int[] WP_COUNT = {2, 4, 8, 14};
    private static final double[] WP_RANGE = {8.0, 14.0, 22.0};
    private static final int[] HIT_N = {6, 11, 20};

    public static int teColor = ci("Purple"), teStyle = 0, teSize = 1, teSpeed = 1, teLine = 1;
    public static int trColor = ci("Cyan"), trLength = 1, trLine = 1, trWho = 0;
    public static int jcColor = ci("Purple"), jcRadius = 1, jcSpeed = 1, jcLine = 1;
    public static int boColor = ci("Purple"), boMode = 0, boLine = 1, boPulse = 1;
    public static int oeMode = 0, oeLine = 1, oePulse = 1;               // Ore ESP (BlockOverlay look)
    public static int wpType = 6, wpDensity = 1, wpRange = 1;
    public static int hitColor = ci("Yellow"), hitType = 3, hitCount = 1;

    private static int fxTick = 0;
    private static boolean jcWasGround = true;
    private static final List<double[]> circles = new ArrayList<>();                    // x, y, z, age
    private static final java.util.Map<Integer, ArrayList<double[]>> trailPts = new java.util.HashMap<>();  // x, y, z, tick

    private static final class Cam {
        Vec3 eye, fwd, right, up;
        double tanHalf, aspect;
        int sw, sh;

        int[] pr(double x, double y, double z) {
            return project(new Vec3(x, y, z), eye, fwd, right, up, tanHalf, aspect, sw, sh);
        }
    }

    private static Cam makeCam(Minecraft mc, LocalPlayer self, float pt) {
        Cam c = new Cam();
        float yaw = (float) Math.toRadians(self.getViewYRot(pt));
        float pitch = (float) Math.toRadians(self.getViewXRot(pt));
        c.fwd = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        c.right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        c.up = c.right.cross(c.fwd);
        c.eye = self.getEyePosition(pt);
        c.sw = mc.getWindow().getGuiScaledWidth();
        c.sh = mc.getWindow().getGuiScaledHeight();
        c.tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        c.aspect = (double) c.sw / c.sh;
        return c;
    }

    private static int hsvRgb(float h) {
        float f = h * 6.0f - (int) (h * 6.0f);
        float q = 1.0f - f;
        float r, g, b;
        switch (((int) (h * 6.0f)) % 6) {
            case 0: r = 1; g = f; b = 0; break;
            case 1: r = q; g = 1; b = 0; break;
            case 2: r = 0; g = 1; b = f; break;
            case 3: r = 0; g = q; b = 1; break;
            case 4: r = f; g = 0; b = 1; break;
            default: r = 1; g = 0; b = q; break;
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    // color from the shared palette; the last entry is an animated rainbow
    public static int fxRgb(int idx, long now, int phase) {
        int rgb = COLOR_RGB[Mth.clamp(idx, 0, COLOR_RGB.length - 1)];
        if (rgb == -1) return hsvRgb((float) (((now / 8 + phase) % 360) / 360.0));
        if (rgb < -1) {
            int[] pr = ANIM_PAL[-rgb - 2];
            double k = 0.5 + 0.5 * Math.sin((now + phase * 40L) * 0.002);
            return lerpRgb(pr[0], pr[1], k);
        }
        return rgb;
    }

    private static void drawLine(GuiGraphics g, int x0, int y0, int x1, int y1, int th, int argb) {
        if ((argb >>> 24) < 5) return;
        int dx = x1 - x0, dy = y1 - y0;
        int n = Math.max(Math.abs(dx), Math.abs(dy));
        if (n > 500) return;
        if (n == 0) {
            g.fill(x0, y0, x0 + th, y0 + th, argb);
            return;
        }
        for (int i = 0; i <= n; i++) {
            int x = x0 + dx * i / n, y = y0 + dy * i / n;
            g.fill(x, y, x + th, y + th, argb);
        }
    }

    private static void fillDisc(GuiGraphics g, int cx, int cy, int r, int argb) {
        if ((argb >>> 24) < 4) return;
        for (int dy = -r; dy <= r; dy++) {
            int hw = (int) Math.sqrt((double) r * r - (double) dy * dy);
            g.fill(cx - hw, cy + dy, cx + hw + 1, cy + dy + 1, argb);
        }
    }

    // A glowing sphere: soft halo (only for the head of the tail), colored body and a bright core.
    private static void drawOrb(GuiGraphics g, Cam cam, double x, double y, double z, double worldR,
                                int rgb, int alpha, boolean halo) {
        int[] c = cam.pr(x, y, z);
        if (c == null) return;
        double zc = new Vec3(x, y, z).subtract(cam.eye).dot(cam.fwd);
        int rad = Mth.clamp((int) (worldR / (zc * cam.tanHalf) * cam.sh / 2.0), 2, 40);
        rgb &= 0xFFFFFF;
        if (halo) {
            int step = Math.max(1, rad / 3);
            fillDisc(g, c[0], c[1], rad + 3 * step, ((int) (alpha * 0.10) << 24) | rgb);
            fillDisc(g, c[0], c[1], rad + 2 * step, ((int) (alpha * 0.16) << 24) | rgb);
            fillDisc(g, c[0], c[1], rad + step, ((int) (alpha * 0.28) << 24) | rgb);
        }
        fillDisc(g, c[0], c[1], rad, (alpha << 24) | rgb);
        fillDisc(g, c[0], c[1], Math.max(1, rad / 2), (alpha << 24) | lerpRgb(rgb, 0xFFFFFF, 0.65));
    }

    private static void drawRing(GuiGraphics g, Cam c, double cx, double cy, double cz, double r,
                                 int segs, int dashOff, int dashMod, int dashOn, int th, int colorIdx, long now, int alpha) {
        int[] prev = null;
        for (int i = 0; i <= segs; i++) {
            double a = i * 2.0 * Math.PI / segs;
            int[] pt = c.pr(cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r);
            if (prev != null && pt != null && Math.floorMod(i + dashOff, dashMod) < dashOn) {
                drawLine(g, prev[0], prev[1], pt[0], pt[1], th, (alpha << 24) | fxRgb(colorIdx, now, i * 8));
            }
            prev = pt;
        }
    }

    private static void addTrailPoint(Entity e, int len) {
        ArrayList<double[]> l = trailPts.computeIfAbsent(e.getId(), k -> new ArrayList<>());
        double x = e.getX(), y = e.getY() + 0.05, z = e.getZ();
        if (!l.isEmpty()) {
            double[] last = l.get(l.size() - 1);
            if (Math.abs(last[0] - x) + Math.abs(last[1] - y) + Math.abs(last[2] - z) < 0.04) return;
        }
        l.add(new double[]{x, y, z, fxTick});
    }

    // render distance override (client only); "Default" leaves the player's own setting alone
    public static final String[] RD_NAMES = {"Default", "6", "8", "12", "16", "24", "32"};
    private static final int[] RD_VALUES = {0, 6, 8, 12, 16, 24, 32};
    public static int rdIndex = 0;
    private static int rdOriginal = -1;

    private static void tickRenderDistance(Minecraft mc) {
        if (rdIndex != 0) {
            if (rdOriginal < 0) rdOriginal = mc.options.renderDistance().get();
            int want = RD_VALUES[rdIndex];
            if (mc.options.renderDistance().get() != want) mc.options.renderDistance().set(want);
        } else if (rdOriginal >= 0) {
            mc.options.renderDistance().set(rdOriginal);
            rdOriginal = -1;
        }
    }

    private static void tickShapes(Minecraft mc, LocalPlayer p) {
        fxTick++;
        tickRenderDistance(mc);
        if (mc.level == null) return;

        // jump circles
        boolean air = !p.onGround();
        if (JUMPCIRCLES.enabled && jcWasGround && air && p.getDeltaMovement().y > 0.1 && circles.size() < 8) {
            circles.add(new double[]{p.getX(), p.getY(), p.getZ(), 0});
        }
        jcWasGround = p.onGround();
        final int life = JC_LIFE[jcSpeed];
        for (double[] j : circles) j[3]++;
        circles.removeIf(j -> j[3] > life);
        if (!JUMPCIRCLES.enabled) circles.clear();

        // trails
        if (TRAILS.enabled) {
            final int len = TR_LEN[trLength];
            addTrailPoint(p, len);
            if (trWho == 1) {
                for (Entity e : mc.level.getEntities(p, p.getBoundingBox().inflate(48.0),
                        en -> en instanceof net.minecraft.world.entity.player.Player)) {
                    addTrailPoint(e, len);
                }
            }
            for (ArrayList<double[]> l : trailPts.values()) l.removeIf(q -> fxTick - q[3] > len);
            trailPts.values().removeIf(l -> l.isEmpty());
        } else {
            trailPts.clear();
        }

        // ambient world particles
        if (WORLDPART.enabled) {
            int n = WP_COUNT[wpDensity];
            double r = WP_RANGE[wpRange];
            double vy = (wpType == 6 || wpType == 10) ? -0.03 : 0.01;
            net.minecraft.core.particles.ParticleOptions opt = pfx(wpType);
            for (int i = 0; i < n; i++) {
                mc.level.addParticle(opt, p.getX() + rnd(r), p.getY() + KA_RNG.nextDouble() * r * 0.6 - 1.0, p.getZ() + rnd(r),
                        rnd(0.02), vy, rnd(0.02));
            }
        }
    }

    private static void renderShapes(GuiGraphics g, Minecraft mc, LocalPlayer self, long now, float pt) {
        if (mc.level == null) return;
        Cam cam = makeCam(mc, self, pt);

        // trails
        if (TRAILS.enabled) {
            int th = LINE_PX[trLine];
            int len = TR_LEN[trLength];
            for (ArrayList<double[]> pts : trailPts.values()) {
                int[] prev = null;
                for (int i = 0; i < pts.size(); i++) {
                    double[] q = pts.get(i);
                    int[] c = cam.pr(q[0], q[1], q[2]);
                    if (c != null && prev != null) {
                        int a = (int) (230 * (1.0 - (fxTick - q[3]) / len));
                        drawLine(g, prev[0], prev[1], c[0], c[1], th, (a << 24) | fxRgb(trColor, now, i * 6));
                    }
                    prev = c;
                }
            }
        }

        // jump circles
        if (JUMPCIRCLES.enabled) {
            int th = LINE_PX[jcLine];
            for (double[] j : circles) {
                double k = j[3] / JC_LIFE[jcSpeed];
                double r = Math.max(0.05, JC_RADIUS[jcRadius] * (1.0 - Math.pow(1.0 - k, 2)));
                int a = (int) (230 * (1.0 - k));
                drawRing(g, cam, j[0], j[1] + 0.02, j[2], r, 40, 0, 1, 1, th, jcColor, now, a);
                drawRing(g, cam, j[0], j[1] + 0.02, j[2], r * 0.6, 32, 0, 1, 1, th, jcColor, now, a / 2);
            }
        }

        // target ESP
        LivingEntity t = thTarget;
        if (TARGETESP.enabled && t != null) {
            double x = Mth.lerp(pt, t.xo, t.getX()), y = Mth.lerp(pt, t.yo, t.getY()), z = Mth.lerp(pt, t.zo, t.getZ());
            double h = t.getBbHeight();
            double r = (t.getBbWidth() * 0.5 + 0.35) * TE_SIZE[teSize];
            double spd = TE_SPEED[teSpeed];
            int off = (int) (now * spd / 70.0);
            int th = LINE_PX[teLine];
            if (teStyle == 1) {                                      // ring sliding up and down the body
                double k = 0.5 + 0.5 * Math.sin(now * 0.0025 * spd);
                drawRing(g, cam, x, y + h * k, z, r, 48, 0, 1, 1, th, teColor, now, 230);
                drawRing(g, cam, x, y + h * Math.max(0.0, k - 0.08), z, r, 48, 0, 1, 1, th, teColor, now, 90);
            } else if (teStyle == 2) {                               // two dashed rings, opposite directions
                drawRing(g, cam, x, y + h * 0.3, z, r, 48, off, 6, 3, th, teColor, now, 230);
                drawRing(g, cam, x, y + h * 0.7, z, r, 48, -off, 6, 3, th, teColor, now, 230);
            } else if (teStyle == 3) {                               // three glowing spheres orbiting the target
                double orbR = 0.14 * TE_SIZE[teSize];
                for (int i = 0; i < 3; i++) {
                    for (int k = 9; k >= 0; k--) {                   // k > 0: the fading tail behind the sphere
                        double tm = now - k * 30.0;
                        double ang = tm * 0.0035 * spd + i * Math.PI * 2.0 / 3.0;
                        double oy = y + h * (0.5 + 0.38 * Math.sin(tm * 0.0021 * spd + i * 2.1));
                        double fade = 1.0 - k / 10.0;
                        drawOrb(g, cam, x + Math.cos(ang) * r, oy, z + Math.sin(ang) * r,
                                orbR * (0.45 + 0.55 * fade), fxRgb(teColor, now, i * 40),
                                k == 0 ? 235 : (int) (190 * fade * fade), k == 0);
                    }
                }
            } else {                                                 // dashed ring at the feet
                drawRing(g, cam, x, y + 0.05, z, r, 48, off, 6, 4, th, teColor, now, 230);
            }
        }

        // block overlay
        if (BLOCKOVERLAY.enabled && mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult bhr
                && bhr.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK) {
            BlockPos bp = bhr.getBlockPos();
            double pulse = boPulse == 1 ? 0.65 + 0.35 * Math.sin(now * 0.004) : 1.0;
            drawBlockBox(g, cam, bp.getX(), bp.getY(), bp.getZ(), bhr.getDirection(),
                    fxRgb(boColor, now, 0), (int) (230 * pulse), LINE_PX[boLine], boMode);
        }
    }


    // Block-overlay look shared by BlockOverlay and Ore ESP: mode 0 = outline, 1 = fill, 2 = both.
    // The fill is a set of thin stripes on the given face, the outline is the 12 edges of the cube.
    private static void drawBlockBox(GuiGraphics g, Cam cam, int ix, int iy, int iz, Direction face,
                                     int rgb, int a, int th, int mode) {
        double bx = ix, by = iy, bz = iz;
        if (mode != 0) {
            double[][] f;
            switch (face) {
                case UP:    f = new double[][]{{bx, by + 1, bz}, {bx + 1, by + 1, bz}, {bx + 1, by + 1, bz + 1}, {bx, by + 1, bz + 1}}; break;
                case DOWN:  f = new double[][]{{bx, by, bz}, {bx + 1, by, bz}, {bx + 1, by, bz + 1}, {bx, by, bz + 1}}; break;
                case NORTH: f = new double[][]{{bx, by, bz}, {bx + 1, by, bz}, {bx + 1, by + 1, bz}, {bx, by + 1, bz}}; break;
                case SOUTH: f = new double[][]{{bx, by, bz + 1}, {bx + 1, by, bz + 1}, {bx + 1, by + 1, bz + 1}, {bx, by + 1, bz + 1}}; break;
                case WEST:  f = new double[][]{{bx, by, bz}, {bx, by, bz + 1}, {bx, by + 1, bz + 1}, {bx, by + 1, bz}}; break;
                default:    f = new double[][]{{bx + 1, by, bz}, {bx + 1, by, bz + 1}, {bx + 1, by + 1, bz + 1}, {bx + 1, by + 1, bz}}; break;
            }
            int[] p0 = cam.pr(f[0][0], f[0][1], f[0][2]), p1 = cam.pr(f[1][0], f[1][1], f[1][2]);
            int[] p2 = cam.pr(f[2][0], f[2][1], f[2][2]), p3 = cam.pr(f[3][0], f[3][1], f[3][2]);
            if (p0 != null && p1 != null && p2 != null && p3 != null) {
                int steps = 14;
                for (int k = 0; k <= steps; k++) {
                    double u = (double) k / steps;
                    drawLine(g, (int) (p0[0] + (p1[0] - p0[0]) * u), (int) (p0[1] + (p1[1] - p0[1]) * u),
                            (int) (p3[0] + (p2[0] - p3[0]) * u), (int) (p3[1] + (p2[1] - p3[1]) * u),
                            2, (((int) (a * 0.18)) << 24) | (rgb & 0xFFFFFF));
                }
            }
        }
        if (mode != 1) {
            int[][] c = new int[8][];
            for (int i = 0; i < 8; i++) c[i] = cam.pr(bx + (i & 1), by + ((i >> 1) & 1), bz + ((i >> 2) & 1));
            for (int i = 0; i < 8; i++) {
                for (int b = 1; b <= 4; b <<= 1) {
                    if ((i & b) != 0) continue;
                    int[] e0 = c[i], e1 = c[i | b];
                    if (e0 != null && e1 != null) drawLine(g, e0[0], e0[1], e1[0], e1[1], th, (a << 24) | (rgb & 0xFFFFFF));
                }
            }
        }
    }

    // ---------------------------------------------------------------- Fog + sky mode (FogRendererMixin calls applyFog)
    public static final String[] FOG_DIST_NAMES = {"32", "64", "128", "256", "512"};
    public static final String[] FOG_START_NAMES = {"0%", "25%", "50%", "75%"};
    public static final String[] SKY_NAMES = {"Off", "Nebula", "Aurora", "Galaxy", "Sunset", "Lava"};
    private static final float[] FOG_DIST = {32f, 64f, 128f, 256f, 512f};
    private static final float[] FOG_START_PCT = {0f, 0.25f, 0.5f, 0.75f};
    private static final int[][] SKY_PAL = {
            {0, 0}, {0x6A2CFF, 0xFF3CA0}, {0x20FF90, 0x2090FF}, {0x0B1030, 0x3B1A7A}, {0xFF7A30, 0xFF4F7A}, {0xFF2A00, 0xFF8A00}
    };
    public static int fogColorIdx = ci("Cyan"), fogDistIdx = 1, fogStartIdx = 1, skyMode = 0;

    private static int lerpRgb(int a, int b, double k) {
        int r = (int) (((a >> 16) & 255) * (1 - k) + ((b >> 16) & 255) * k);
        int g = (int) (((a >> 8) & 255) * (1 - k) + ((b >> 8) & 255) * k);
        int bl = (int) ((a & 255) * (1 - k) + (b & 255) * k);
        return (r << 16) | (g << 8) | bl;
    }

    // Called with the FogData that FogRenderer.setupFog returns. Field names are matched by reflection
    // (start / end / color), so a renamed field only disables that part instead of breaking the game.
    public static void applyFog(Object fd) {
        if (fd == null || (!FOG.enabled && skyMode == 0)) return;
        long now = System.currentTimeMillis();
        int rgb;
        if (skyMode != 0) {
            double k = 0.5 + 0.5 * Math.sin(now * 0.0006);
            rgb = lerpRgb(SKY_PAL[skyMode][0], SKY_PAL[skyMode][1], k);
        } else {
            rgb = fxRgb(fogColorIdx, now, 0);
        }
        float end = FOG_DIST[fogDistIdx];
        float start = end * FOG_START_PCT[fogStartIdx];
        try {
            for (java.lang.reflect.Field f : fd.getClass().getDeclaredFields()) {
                if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                f.setAccessible(true);
                String n = f.getName().toLowerCase();
                Class<?> t = f.getType();
                if (t == float.class) {
                    if (!FOG.enabled) continue;
                    if (n.contains("start")) f.setFloat(fd, start);
                    else if (n.contains("end")) f.setFloat(fd, end);
                } else if (n.contains("color")) {
                    if (t == int.class) {
                        f.setInt(fd, 0xFF000000 | rgb);
                    } else {
                        Object c = f.get(fd);
                        if (c != null) {
                            c.getClass().getMethod("set", float.class, float.class, float.class, float.class)
                                    .invoke(c, ((rgb >> 16) & 255) / 255.0f, ((rgb >> 8) & 255) / 255.0f, (rgb & 255) / 255.0f, 1.0f);
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }

    // ---------------------------------------------------------------- Pulse-style visuals
    // Hit sparks and floating damage numbers (projected to the screen by hand like the ESP), a Target HUD
    // and item cooldown indicators.
    private static final java.util.Map<Integer, Float> hpSeen = new java.util.HashMap<>();
    private static final List<double[]> floaters = new ArrayList<>();   // x, y, z, amount, age, crit(0/1)
    private static final List<double[]> sparks = new ArrayList<>();     // x, y, z, vx, vy, vz, age, rgb
    private static LivingEntity thTarget = null;
    private static int thSeen = 0;
    private static float thHpAnim = 1.0f;
    private static final Item[] CD_ITEMS = {
            Items.ENDER_PEARL, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE,
            Items.CHORUS_FRUIT, Items.SHIELD, Items.WIND_CHARGE
    };

    private static void tickVisuals(Minecraft mc, LocalPlayer p) {
        if (mc.level == null) return;

        if (weatherMode != 0) {                                      // client-side weather override
            mc.level.setRainLevel(weatherMode == 1 ? 0.0f : 1.0f);
            mc.level.setThunderLevel(weatherMode == 3 ? 1.0f : 0.0f);
        }
        if (PARTICLES.enabled && !p.isSpectator()) tickParticleFx(mc, p);

        // Target HUD: the entity closest to the crosshair, kept for 3 seconds after it leaves it
        if (TARGETHUD.enabled || TARGETESP.enabled) {
            Entity t = nearestTarget(mc, p, 8.0, true);
            if (t instanceof LivingEntity le) {
                if (le != thTarget) thHpAnim = Mth.clamp(le.getHealth() / Math.max(1.0f, le.getMaxHealth()), 0.0f, 1.0f);
                thTarget = le;
                thSeen = p.tickCount;
            }
            if (thTarget != null && (p.tickCount - thSeen > 60 || !thTarget.isAlive() || thTarget.isRemoved())) thTarget = null;
            if (thTarget != null) {
                float ratio = Mth.clamp(thTarget.getHealth() / Math.max(1.0f, thTarget.getMaxHealth()), 0.0f, 1.0f);
                thHpAnim += (ratio - thHpAnim) * 0.2f;
            }
        } else {
            thTarget = null;
        }

        if (!DMGNUM.enabled && !HITFX.enabled) {
            hpSeen.clear();
            floaters.clear();
            sparks.clear();
            return;
        }

        // watch health changes of the living entities around
        for (Entity e : mc.level.getEntities(p, p.getBoundingBox().inflate(48.0), en -> en instanceof LivingEntity)) {
            LivingEntity le = (LivingEntity) e;
            float hp = le.getHealth();
            Float prev = hpSeen.put(le.getId(), hp);
            if (prev == null || Math.abs(prev - hp) < 0.5f) continue;
            float dmg = prev - hp;                                   // > 0: damage, < 0: healing
            boolean crit = dmg >= 6.0f;
            if (DMGNUM.enabled && floaters.size() < 40) {
                floaters.add(new double[]{le.getX(), le.getY() + le.getBbHeight() + 0.3, le.getZ(), dmg, 0, crit ? 1 : 0});
            }
            if (HITFX.enabled && dmg > 0 && sparks.size() < 300) {
                int n = crit ? HIT_N[hitCount] * 2 : HIT_N[hitCount];
                int rgb = crit ? 0xFF3030 : fxRgb(hitColor, System.currentTimeMillis(), 0);
                if (hitWorldFx) {
                    for (int i = 0; i < (crit ? 14 : 8); i++) {
                        mc.level.addParticle(pfx(hitType), le.getX() + rnd(0.3), le.getY() + le.getBbHeight() * 0.6 + rnd(0.3), le.getZ() + rnd(0.3),
                                rnd(0.15), KA_RNG.nextDouble() * 0.15, rnd(0.15));
                    }
                }
                for (int i = 0; i < n; i++) {
                    sparks.add(new double[]{le.getX(), le.getY() + le.getBbHeight() * 0.6, le.getZ(),
                            (KA_RNG.nextDouble() - 0.5) * 0.35, KA_RNG.nextDouble() * 0.25 + 0.05, (KA_RNG.nextDouble() - 0.5) * 0.35,
                            0, rgb});
                }
            }
        }
        if (hpSeen.size() > 512) hpSeen.clear();

        for (double[] f : floaters) f[4]++;
        floaters.removeIf(f -> f[4] > 25);
        for (double[] s : sparks) {
            s[0] += s[3];
            s[1] += s[4];
            s[2] += s[5];
            s[4] -= 0.03;
            s[3] *= 0.92;
            s[5] *= 0.92;
            s[6]++;
        }
        sparks.removeIf(s -> s[6] > 14);
    }

    private static int fade(int rgb, double age, double life) {
        int a = (int) Mth.clamp(255 * (1.0 - age / life), 4, 255);
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    private static void renderWorldFx(GuiGraphics graphics, Minecraft mc, LocalPlayer self, Font font, float pt) {
        if (mc.level == null || (floaters.isEmpty() && sparks.isEmpty())) return;

        float yaw = (float) Math.toRadians(self.getViewYRot(pt));
        float pitch = (float) Math.toRadians(self.getViewXRot(pt));
        Vec3 fwd = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3 up = right.cross(fwd);
        Vec3 eye = self.getEyePosition(pt);
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        double tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        double aspect = (double) sw / sh;

        for (double[] s : sparks) {
            int[] c = project(new Vec3(s[0], s[1], s[2]), eye, fwd, right, up, tanHalf, aspect, sw, sh);
            if (c == null) continue;
            int size = s[7] == 0xFF3030 ? 3 : 2;
            graphics.fill(c[0], c[1], c[0] + size, c[1] + size, fade((int) s[7], s[6], 14));
        }

        for (double[] f : floaters) {
            double rise = f[4] * 0.04;
            int[] c = project(new Vec3(f[0], f[1] + rise, f[2]), eye, fwd, right, up, tanHalf, aspect, sw, sh);
            if (c == null) continue;
            boolean heal = f[3] < 0;
            String txt = (heal ? "+" : "-") + String.format("%.1f", Math.abs(f[3])) + (f[5] > 0 ? "!" : "");
            int rgb = heal ? 0x55FF55 : (f[5] > 0 ? 0xFF4040 : 0xFFD040);
            graphics.drawString(font, txt, c[0] - font.width(txt) / 2, c[1], fade(rgb, f[4], 25), true);
        }
    }

    private static void renderTargetHud(GuiGraphics g, Minecraft mc, LocalPlayer p, Font font, long now) {
        LivingEntity t = thTarget;
        if (t == null) return;
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        int w = 118, h = 38;
        int x = sw / 2 + 16, y = sh / 2 + 16;

        g.fill(x, y, x + w, y + h, 0xA0000000);
        g.fill(x, y, x + w, y + 1, hudColor(now, 0));
        String name = t.getName().getString();
        if (name.length() > 14) name = name.substring(0, 14);
        g.drawString(font, name, x + 4, y + 5, 0xFFFFFFFF, true);

        float ratio = Mth.clamp(t.getHealth() / Math.max(1.0f, t.getMaxHealth()), 0.0f, 1.0f);
        int hpColor = 0xFF000000 | ((int) (255 * (1.0f - ratio)) << 16) | ((int) (255 * ratio) << 8) | 0x30;
        int bx = x + 4, by = y + 17, bw = w - 28;
        g.fill(bx, by, bx + bw, by + 5, 0xFF202020);
        g.fill(bx, by, bx + (int) (bw * Mth.clamp(thHpAnim, 0.0f, 1.0f)), by + 5, hpColor);

        String info = String.format("%.1f HP  AR %d  %.1fm", t.getHealth(), t.getArmorValue(), (double) p.distanceTo(t));
        g.drawString(font, info, x + 4, y + 26, 0xFFB0B0B0, true);
        ItemStack hand = t.getMainHandItem();
        if (!hand.isEmpty()) g.renderItem(hand, x + w - 20, y + 4);
    }

    private static void renderCooldowns(GuiGraphics g, Minecraft mc, LocalPlayer p, float pt, long now) {
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        int x = sw - 72, y = sh / 2 - 50;
        for (Item it : CD_ITEMS) {
            ItemStack st = new ItemStack(it);
            float pc = p.getCooldowns().getCooldownPercent(st, pt);
            if (pc <= 0.0f) continue;
            g.fill(x - 2, y - 2, x + 68, y + 18, 0xA0000000);
            g.fill(x - 2, y - 2, x - 1, y + 18, hudColor(now, 0));
            g.renderItem(st, x, y);
            g.fill(x + 22, y + 6, x + 64, y + 11, 0xFF202020);
            g.fill(x + 22, y + 6, x + 22 + (int) (42 * Mth.clamp(pc, 0.0f, 1.0f)), y + 11, hudColor(now, 0));
            y += 22;
        }
    }

    // Animated blue -> purple gradient used by the HUD (phase shifts per element).
    public static int hudColor(long now, int phaseMs) {
        double t = ((now + phaseMs) % 3000L) / 3000.0;
        double k = 0.5 + 0.5 * Math.sin(t * Math.PI * 2);
        int r = (int) (90 + 120 * k), g = (int) (120 - 40 * k), bl = 255;
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // Outline color for ESP-highlighted entities (RGB), or -1 if the entity is not highlighted.
    // Players: green -> red by health, hostile mobs: orange, items: cyan.
    public static int espColor(Entity e) {
        Minecraft mc = Minecraft.getInstance();
        if (e == mc.player) return -1;
        if (ESP_MOBS.enabled && e instanceof Enemy) return 0xFF8000;
        if (ESP_ITEMS.enabled && e instanceof net.minecraft.world.entity.item.ItemEntity) return 0x00FFFF;
        return -1;
    }

    // Player ESP (Delta style): 2D box with a health bar, a dark nametag plate and the gear icons above it.
    // Everything is projected to the screen by hand, so it needs no render hooks and shows through walls.
    private static void renderGearView(GuiGraphics graphics, Minecraft mc, LocalPlayer self,
                                       Font font, float pt) {
        if (mc.level == null) return;

        float yaw = (float) Math.toRadians(self.getViewYRot(pt));
        float pitch = (float) Math.toRadians(self.getViewXRot(pt));
        Vec3 fwd = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3 up = right.cross(fwd);
        Vec3 eye = self.getEyePosition(pt);
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        double tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        double aspect = (double) sw / sh;
        long now = System.currentTimeMillis();

        for (Player t : mc.level.players()) {
            if (t == self || t.isSpectator() || !t.isAlive()) continue;
            if (self.distanceToSqr(t) > 128.0 * 128.0) continue;

            Vec3 off = new Vec3(Mth.lerp(pt, t.xo, t.getX()) - t.getX(),
                    Mth.lerp(pt, t.yo, t.getY()) - t.getY(),
                    Mth.lerp(pt, t.zo, t.getZ()) - t.getZ());
            int[] b = screenBox(t.getBoundingBox().move(off), eye, fwd, right, up, tanHalf, aspect, sw, sh);
            if (b == null || b[2] < 0 || b[0] > sw || b[3] < 0 || b[1] > sh) continue;

            float ratio = Mth.clamp(t.getHealth() / Math.max(1.0f, t.getMaxHealth()), 0.0f, 1.0f);
            int hpColor = 0xFF000000 | ((int) (255 * (1.0f - ratio)) << 16) | ((int) (255 * ratio) << 8) | 0x30;

            if (ESP_PLAYERS.enabled) {
                int accent = hudColor(now, 0);
                outline(graphics, b[0] - 1, b[1] - 1, b[2] + 1, b[3] + 1, 0xFF000000);   // dark outer edge
                outline(graphics, b[0], b[1], b[2], b[3], accent);
                // health bar on the left side of the box
                int bx2 = b[0] - 3, bx1 = bx2 - 2;
                graphics.fill(bx1 - 1, b[1] - 1, bx2 + 1, b[3] + 1, 0xFF000000);
                int barH = Math.max(1, (int) ((b[3] - b[1]) * ratio));
                graphics.fill(bx1, b[3] - barH, bx2, b[3], hpColor);
            }

            // nametag plate above the box
            String name = t.getName().getString();
            String hp = String.valueOf((int) Math.ceil(t.getHealth()));
            int tw = font.width(name) + 4 + font.width(hp);
            int cx = (b[0] + b[2]) / 2;
            int px1 = cx - tw / 2 - 3, px2 = cx + tw / 2 + 3;
            int py2 = b[1] - 3, py1 = py2 - font.lineHeight - 2;
            graphics.fill(px1, py1, px2, py2, 0x90000000);
            graphics.fill(px1, py2 - 1, px2, py2, hudColor(now, 0));
            graphics.drawString(font, name, px1 + 3, py1 + 2, 0xFFFFFFFF, true);
            graphics.drawString(font, hp, px1 + 3 + font.width(name) + 4, py1 + 2, hpColor, true);

            // gear icons: main hand, helmet, chest, legs, boots, offhand
            ItemStack[] icons = {
                    t.getItemBySlot(EquipmentSlot.MAINHAND), t.getItemBySlot(EquipmentSlot.HEAD),
                    t.getItemBySlot(EquipmentSlot.CHEST), t.getItemBySlot(EquipmentSlot.LEGS),
                    t.getItemBySlot(EquipmentSlot.FEET), t.getItemBySlot(EquipmentSlot.OFFHAND)
            };
            int step = 18;
            int x0 = cx - (icons.length * step - 2) / 2;
            int iconY = py1 - 18;
            for (int i = 0; i < icons.length; i++) {
                ItemStack st = icons[i];
                if (st.isEmpty()) continue;
                graphics.renderItem(st, x0 + i * step, iconY);
                graphics.renderItemDecorations(font, st, x0 + i * step, iconY);   // count + durability bar
            }
        }
    }

    private static String gearName(ItemStack s) {
        if (s.isEmpty()) return "-";
        String n = s.getHoverName().getString();
        return s.isEnchanted() ? n + "*" : n;
    }
}
