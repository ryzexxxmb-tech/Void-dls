package com.example.friendutil.mixin;

import com.example.friendutil.FriendUtilClient;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {

    // The glow outline takes its color from the team color; override it for ESP targets.
    @Inject(method = "getTeamColor", at = @At("HEAD"), cancellable = true)
    private void friendutil$espColor(CallbackInfoReturnable<Integer> cir) {
        int color = FriendUtilClient.espColor((Entity) (Object) this);
        if (color != -1) cir.setReturnValue(color);
    }
}
