package com.example.friendutil.mixin;

import com.example.friendutil.FriendUtilClient;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {

    // ESP: vanilla glow outline, visible through walls.
    @Inject(method = "shouldEntityAppearGlowing", at = @At("HEAD"), cancellable = true)
    private void friendutil$esp(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (entity == ((Minecraft) (Object) this).player) return;

        boolean glow =
                (FriendUtilClient.ESP_MOBS.enabled && entity instanceof Enemy)
                || (FriendUtilClient.ESP_ITEMS.enabled && entity instanceof ItemEntity);

        if (glow) cir.setReturnValue(true);
    }
}
